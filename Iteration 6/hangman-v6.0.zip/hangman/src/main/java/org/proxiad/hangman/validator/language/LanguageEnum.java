package org.proxiad.hangman.validator.language;

public enum LanguageEnum {

  BULGARIAN, ENGLISH
}

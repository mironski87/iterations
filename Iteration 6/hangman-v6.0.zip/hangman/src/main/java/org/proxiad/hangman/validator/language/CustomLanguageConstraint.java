package org.proxiad.hangman.validator.language;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.Arrays;

public class CustomLanguageConstraint
    implements ConstraintValidator<CustomLanguageValidator, LanguageEnum> {

  @Override
  public boolean isValid(LanguageEnum value, ConstraintValidatorContext context) {

    return value != null && Arrays.asList(LanguageEnum.values()).contains(value);
  }

}

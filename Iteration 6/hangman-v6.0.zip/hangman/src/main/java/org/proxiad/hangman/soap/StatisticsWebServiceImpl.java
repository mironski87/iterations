package org.proxiad.hangman.soap;

import jakarta.jws.WebService;
import java.util.List;
import java.util.stream.Collectors;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.repository.StatisticRepository;
import org.springframework.stereotype.Service;

@WebService(endpointInterface = "org.proxiad.hangman.soap.StatisticWebService")
@Service
public class StatisticsWebServiceImpl implements StatisticWebService {

  private StatisticRepository repository;

  public StatisticsWebServiceImpl(StatisticRepository repository) {
    this.repository = repository;
  }

  @Override
  public List<Statistic> getAllStatistics() {
    return repository.findAll().stream().limit(10).collect(Collectors.toList());
  }
}

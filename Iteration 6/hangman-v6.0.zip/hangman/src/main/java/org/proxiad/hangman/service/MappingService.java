package org.proxiad.hangman.service;

import org.proxiad.hangman.models.GameDTO;
import org.proxiad.hangman.validator.language.LanguageEnum;

public interface MappingService {

  GameDTO startNewGame(LanguageEnum language, String sessionId);

  GameDTO getGameById(Long id);

  GameDTO makeGuess(Long gameId, char letter, String sessionId);
}

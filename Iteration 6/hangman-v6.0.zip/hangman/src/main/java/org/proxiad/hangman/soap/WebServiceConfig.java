package org.proxiad.hangman.soap;

import jakarta.xml.ws.Endpoint;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class WebServiceConfig {

  private Bus bus;
  private StatisticWebService statisticWebService;

  public WebServiceConfig(Bus bus, StatisticWebService statisticWebService) {
    this.bus = bus;
    this.statisticWebService = statisticWebService;
  }

  @Bean
  public Endpoint endpoint() {
    System.out.println("TEST");
    EndpointImpl endpoint = new EndpointImpl(bus, statisticWebService);
    endpoint.publish("/statistics");
    return endpoint;
  }
}

package org.proxiad.hangman.models;

import lombok.Data;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Data
public class GameDTO {

  private long gameId;
  private String maskedWord;
  private String wrongTriesChars;
  private int wrongTries;
  private LanguageEnum language;
  private boolean isWon;
  private boolean isLost;
}

package org.proxiad.hangman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("org.proxiad.hangman.*")
public class HangmanApplication {

  public static void main(String[] args) {
    SpringApplication.run(HangmanApplication.class, args);
  }
}

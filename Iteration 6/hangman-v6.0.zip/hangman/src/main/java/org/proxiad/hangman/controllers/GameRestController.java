package org.proxiad.hangman.controllers;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.service.GameService;
import org.proxiad.hangman.validator.models.Input;
import org.proxiad.hangman.validator.models.Language;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GameRestController {

  private GameService gameService;

  public GameRestController(GameService gameService) {
    this.gameService = gameService;
  }

  @GetMapping("/games")
  public List<Game> getOngoingGames() {
    return gameService.listOngoingGames();
  }

  @GetMapping(value = "/games/{gameId}")
  public Game getGame(@PathVariable Long gameId) {
    return gameService.getGame(gameId);
  }

  @PostMapping("/addGame")
  public Game addNewGame(@Valid Language languageValidator, HttpSession session) {
    return gameService.startNewGame(languageValidator.getType(), session.getId());
  }

  @PutMapping("/makeTry/{gameId}")
  public Game makeTry(@PathVariable Long gameId, @Valid Input inputValidator, HttpSession session) {
    return gameService.makeGuess(gameId, inputValidator.getValue().charAt(0), session.getId());
  }
}

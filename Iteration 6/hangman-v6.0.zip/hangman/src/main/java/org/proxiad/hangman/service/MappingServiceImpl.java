package org.proxiad.hangman.service;

import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.GameDTO;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class MappingServiceImpl implements MappingService {

  private GameServiceImpl gameService;

  public MappingServiceImpl(GameServiceImpl gameService) {
    this.gameService = gameService;
  }

  @Override
  public GameDTO startNewGame(LanguageEnum language, String sessionId) {
    return convertDataIntoDTO(gameService.startNewGame(language, sessionId));
  }

  @Override
  public GameDTO getGameById(Long id) {
    return convertDataIntoDTO(gameService.getGame(id));
  }

  @Override
  public GameDTO makeGuess(Long gameId, char letter, String sessionId) {
    return convertDataIntoDTO(gameService.makeGuess(gameId, letter, sessionId));
  }

  private GameDTO convertDataIntoDTO(Game game) {

    Statistic statistic = game.getStatistic();
    GameDTO dto = new GameDTO();

    dto.setGameId(game.getId());
    dto.setMaskedWord(generateMaskedWord(game));
    dto.setWrongTriesChars(statistic.getWrongLetters());
    dto.setWrongTries(statistic.getWrongTries());
    dto.setLanguage(statistic.getLanguage());
    dto.setWon(game.getStatistic().isWon());
    dto.setLost(game.getStatistic().isLost());

    return dto;
  }

  private static String generateMaskedWord(Game game) {

    StringBuilder builder = new StringBuilder("");

    String word = game.getWord();
    String history = game.getHistory();

    for (Character wordChar : word.toCharArray()) {

      boolean isGuessRight = false;

      for (Character historyChar : history.toCharArray()) {

        if (wordChar.equals(historyChar)) {

          isGuessRight = true;
          break;
        }
      }

      char charToAppend = isGuessRight ? wordChar : '*';
      builder.append(charToAppend);
    }

    return builder.toString();
  }
}

package org.proxiad.hangman.service;

import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.repository.GameRepository;
import org.proxiad.hangman.utility.RandomWordUtil;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class GameServiceImpl implements GameService {

  private GameRepository gameRepository;
  private StatisticService statisticService;

  public GameServiceImpl(GameRepository gameRepository, StatisticService statisticService) {
    this.gameRepository = gameRepository;
    this.statisticService = statisticService;
  }

  @Override
  public List<Game> listOngoingGames() {
    return gameRepository.findByStatisticIsWonFalseAndStatisticIsLostFalse();
  }

  @Override
  public Game startNewGame(LanguageEnum language, String sessionId) {

    Game game = new Game();
    game.setWord(RandomWordUtil.generate(language));
    System.out.println(game.getWord());

    game = gameRepository.save(game);
    game.setStatistic(statisticService.addStatistic(language, sessionId, game));
    return game;
  }

  @Override
  public Game getGame(Long id) {
    return gameRepository.findById(id).orElse(null);
  }

  @Override
  public Game makeGuess(Long id, char letter, String sessionId) {

    Game game = getGame(id);

    if (isInvalidGameTry(game, sessionId)) {
      throw new IllegalArgumentException();
    }

    if (doGameHistoryContainsThisLetter(game, letter)) {
      return game;
    }

    if (isLetterWrong(game, letter)) {
      statisticService.wrongCharAdd(game, letter);
    }

    buildHistory(game, letter);

    if (isGameWon(game) || isGameLost(game)) {
      statisticService.finalUpdateStatistic(game, isGameWon(game));
    }

    gameRepository.save(game);

    return game;
  }

  private static boolean isInvalidGameTry(Game game, String sessionId) {

    return // (!game.getStatistic().getSessionId().equals(sessionId)) ||
    (game.getStatistic().isWon() || game.getStatistic().isLost());
  }

  private static boolean doGameHistoryContainsThisLetter(Game game, char letter) {

    for (Character letterItem : game.getHistory().toCharArray()) {
      if (letterItem == letter) {
        return true;
      }
    }

    return false;
  }

  private static boolean isLetterWrong(Game game, char letter) {

    for (Character wordChar : game.getWord().toCharArray()) {
      if (wordChar == letter) {
        return false;
      }
    }

    return true;
  }

  private static void buildHistory(Game game, char letter) {

    StringBuilder builder = new StringBuilder(game.getHistory());
    builder.append(letter);
    game.setHistory(builder.toString());
  }

  private static boolean isGameWon(Game game) {

    for (Character wordChar : game.getWord().toCharArray()) {

      boolean isWordCharInHistory = false;

      for (Character historyChar : game.getHistory().toCharArray()) {

        if (wordChar.equals(historyChar)) {
          isWordCharInHistory = true;
          break;
        }
      }

      if (!isWordCharInHistory) {
        return false;
      }
    }

    return true;
  }

  private static boolean isGameLost(Game game) {
    return game.getStatistic().getWrongTries() >= 6;
  }
}

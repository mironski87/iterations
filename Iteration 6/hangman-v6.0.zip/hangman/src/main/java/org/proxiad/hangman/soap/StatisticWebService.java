package org.proxiad.hangman.soap;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import jakarta.jws.soap.SOAPBinding;
import java.util.List;
import org.proxiad.hangman.models.Statistic;

@WebService(name = "StatisticWebServiceImpl")
@SOAPBinding
public interface StatisticWebService {

  @WebMethod(operationName = "getAllStatistics")
  List<Statistic> getAllStatistics();
}

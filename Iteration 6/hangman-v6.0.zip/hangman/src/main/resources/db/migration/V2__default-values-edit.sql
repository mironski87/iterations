ALTER TABLE game ALTER history SET DEFAULT '';
ALTER TABLE game ALTER word SET DEFAULT '';

ALTER TABLE ranking ALTER fastest_time SET DEFAULT '02:00:00';
ALTER TABLE ranking ALTER last_played SET DEFAULT '2000-01-01';
ALTER TABLE ranking ALTER number_of_losses SET DEFAULT 0;
ALTER TABLE ranking ALTER number_of_wins SET DEFAULT 0;
ALTER TABLE ranking ALTER session_id SET DEFAULT '';

ALTER TABLE statistic ALTER end_time SET DEFAULT '02:00:00';
ALTER TABLE statistic ALTER is_lost SET DEFAULT 0;
ALTER TABLE statistic ALTER is_won SET DEFAULT 0;
ALTER TABLE statistic ALTER language SET DEFAULT '';
ALTER TABLE statistic ALTER session_id SET DEFAULT '';
ALTER TABLE statistic ALTER start_time SET DEFAULT '02:00:00';
ALTER TABLE statistic ALTER wrong_letters SET DEFAULT '';
ALTER TABLE statistic ALTER wrong_tries SET DEFAULT 0;
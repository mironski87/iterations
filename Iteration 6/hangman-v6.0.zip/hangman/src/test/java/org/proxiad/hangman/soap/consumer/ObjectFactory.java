
package org.proxiad.hangman.soap.consumer;

import javax.xml.namespace.QName;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlElementDecl;
import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.proxiad.hangman.soap.consumer package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetAllStatistics_QNAME = new QName("http://soap.hangman.proxiad.org/", "getAllStatistics");
    private final static QName _GetAllStatisticsResponse_QNAME = new QName("http://soap.hangman.proxiad.org/", "getAllStatisticsResponse");
    private final static QName _StatisticRanking_QNAME = new QName("", "ranking");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.proxiad.hangman.soap.consumer
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetAllStatistics }
     * 
     */
    public GetAllStatistics createGetAllStatistics() {
        return new GetAllStatistics();
    }

    /**
     * Create an instance of {@link GetAllStatisticsResponse }
     * 
     */
    public GetAllStatisticsResponse createGetAllStatisticsResponse() {
        return new GetAllStatisticsResponse();
    }

    /**
     * Create an instance of {@link Statistic }
     * 
     */
    public Statistic createStatistic() {
        return new Statistic();
    }

    /**
     * Create an instance of {@link LocalTime }
     * 
     */
    public LocalTime createLocalTime() {
        return new LocalTime();
    }

    /**
     * Create an instance of {@link Game }
     * 
     */
    public Game createGame() {
        return new Game();
    }

    /**
     * Create an instance of {@link Ranking }
     * 
     */
    public Ranking createRanking() {
        return new Ranking();
    }

    /**
     * Create an instance of {@link Time }
     * 
     */
    public Time createTime() {
        return new Time();
    }

    /**
     * Create an instance of {@link LocalDate }
     * 
     */
    public LocalDate createLocalDate() {
        return new LocalDate();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllStatistics }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllStatistics }{@code >}
     */
    @XmlElementDecl(namespace = "http://soap.hangman.proxiad.org/", name = "getAllStatistics")
    public JAXBElement<GetAllStatistics> createGetAllStatistics(GetAllStatistics value) {
        return new JAXBElement<GetAllStatistics>(_GetAllStatistics_QNAME, GetAllStatistics.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAllStatisticsResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetAllStatisticsResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://soap.hangman.proxiad.org/", name = "getAllStatisticsResponse")
    public JAXBElement<GetAllStatisticsResponse> createGetAllStatisticsResponse(GetAllStatisticsResponse value) {
        return new JAXBElement<GetAllStatisticsResponse>(_GetAllStatisticsResponse_QNAME, GetAllStatisticsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ranking }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Ranking }{@code >}
     */
    @XmlElementDecl(namespace = "", name = "ranking", scope = Statistic.class)
    public JAXBElement<Ranking> createStatisticRanking(Ranking value) {
        return new JAXBElement<Ranking>(_StatisticRanking_QNAME, Ranking.class, Statistic.class, value);
    }

}

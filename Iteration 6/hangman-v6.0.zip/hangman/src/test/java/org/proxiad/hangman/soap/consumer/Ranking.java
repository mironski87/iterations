
package org.proxiad.hangman.soap.consumer;

import java.util.ArrayList;
import java.util.List;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ranking complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ranking"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fastestTime" type="{http://soap.hangman.proxiad.org/}time" minOccurs="0"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="lastPlayed" type="{http://soap.hangman.proxiad.org/}localDate" minOccurs="0"/&gt;
 *         &lt;element name="numberOfLosses" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="numberOfWins" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="sessionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="statistics" type="{http://soap.hangman.proxiad.org/}statistic" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ranking", propOrder = {
    "fastestTime",
    "id",
    "lastPlayed",
    "numberOfLosses",
    "numberOfWins",
    "sessionId",
    "statistics"
})
public class Ranking {

    protected Time fastestTime;
    protected Long id;
    protected LocalDate lastPlayed;
    protected Integer numberOfLosses;
    protected Integer numberOfWins;
    protected String sessionId;
    @XmlElement(nillable = true)
    protected List<Statistic> statistics;

    /**
     * Gets the value of the fastestTime property.
     * 
     * @return
     *     possible object is
     *     {@link Time }
     *     
     */
    public Time getFastestTime() {
        return fastestTime;
    }

    /**
     * Sets the value of the fastestTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Time }
     *     
     */
    public void setFastestTime(Time value) {
        this.fastestTime = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * Gets the value of the lastPlayed property.
     * 
     * @return
     *     possible object is
     *     {@link LocalDate }
     *     
     */
    public LocalDate getLastPlayed() {
        return lastPlayed;
    }

    /**
     * Sets the value of the lastPlayed property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalDate }
     *     
     */
    public void setLastPlayed(LocalDate value) {
        this.lastPlayed = value;
    }

    /**
     * Gets the value of the numberOfLosses property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfLosses() {
        return numberOfLosses;
    }

    /**
     * Sets the value of the numberOfLosses property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfLosses(Integer value) {
        this.numberOfLosses = value;
    }

    /**
     * Gets the value of the numberOfWins property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getNumberOfWins() {
        return numberOfWins;
    }

    /**
     * Sets the value of the numberOfWins property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setNumberOfWins(Integer value) {
        this.numberOfWins = value;
    }

    /**
     * Gets the value of the sessionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Sets the value of the sessionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionId(String value) {
        this.sessionId = value;
    }

    /**
     * Gets the value of the statistics property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the Jakarta XML Binding object.
     * This is why there is not a <CODE>set</CODE> method for the statistics property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStatistics().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Statistic }
     * 
     * 
     */
    public List<Statistic> getStatistics() {
        if (statistics == null) {
            statistics = new ArrayList<Statistic>();
        }
        return this.statistics;
    }

}

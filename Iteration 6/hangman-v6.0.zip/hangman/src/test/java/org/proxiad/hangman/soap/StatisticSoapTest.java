package org.proxiad.hangman.soap;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.proxiad.hangman.soap.consumer.Statistic;
import org.proxiad.hangman.soap.consumer.StatisticWebServiceImpl;
import org.proxiad.hangman.soap.consumer.StatisticsWebServiceImplService;

class StatisticSoapTest {

  @Test
  void retrievedDataNotNullTest() {

    StatisticsWebServiceImplService webServiceClient = new StatisticsWebServiceImplService();
    StatisticWebServiceImpl webService = webServiceClient.getStatisticsWebServiceImplPort();

    List<Statistic> retrievedStatistics = webService.getAllStatistics();
    assertNotNull(retrievedStatistics);
  }
}

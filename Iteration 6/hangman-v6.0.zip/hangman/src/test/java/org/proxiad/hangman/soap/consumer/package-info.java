@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://soap.hangman.proxiad.org/")
package org.proxiad.hangman.soap.consumer;

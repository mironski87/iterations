
package org.proxiad.hangman.soap.consumer;

import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElementRef;
import jakarta.xml.bind.annotation.XmlSchemaType;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Java class for statistic complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="statistic"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="endTime" type="{http://soap.hangman.proxiad.org/}localTime" minOccurs="0"/&gt;
 *         &lt;element name="game" type="{http://soap.hangman.proxiad.org/}game" minOccurs="0"/&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *         &lt;element name="language" type="{http://soap.hangman.proxiad.org/}languageEnum" minOccurs="0"/&gt;
 *         &lt;element name="lost" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="ranking" type="{http://soap.hangman.proxiad.org/}ranking" minOccurs="0"/&gt;
 *         &lt;element name="sessionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="startTime" type="{http://soap.hangman.proxiad.org/}localTime" minOccurs="0"/&gt;
 *         &lt;element name="won" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="wrongLetters" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="wrongTries" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "statistic", propOrder = {
    "endTime",
    "game",
    "id",
    "language",
    "lost",
    "ranking",
    "sessionId",
    "startTime",
    "won",
    "wrongLetters",
    "wrongTries"
})
public class Statistic {

    protected LocalTime endTime;
    protected Game game;
    protected Long id;
    @XmlSchemaType(name = "string")
    protected LanguageEnum language;
    protected boolean lost;
    @XmlElementRef(name = "ranking", type = JAXBElement.class, required = false)
    protected JAXBElement<Ranking> ranking;
    protected String sessionId;
    protected LocalTime startTime;
    protected boolean won;
    protected String wrongLetters;
    protected Integer wrongTries;

    /**
     * Gets the value of the endTime property.
     * 
     * @return
     *     possible object is
     *     {@link LocalTime }
     *     
     */
    public LocalTime getEndTime() {
        return endTime;
    }

    /**
     * Sets the value of the endTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalTime }
     *     
     */
    public void setEndTime(LocalTime value) {
        this.endTime = value;
    }

    /**
     * Gets the value of the game property.
     * 
     * @return
     *     possible object is
     *     {@link Game }
     *     
     */
    public Game getGame() {
        return game;
    }

    /**
     * Sets the value of the game property.
     * 
     * @param value
     *     allowed object is
     *     {@link Game }
     *     
     */
    public void setGame(Game value) {
        this.game = value;
    }

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setId(Long value) {
        this.id = value;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link LanguageEnum }
     *     
     */
    public LanguageEnum getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param value
     *     allowed object is
     *     {@link LanguageEnum }
     *     
     */
    public void setLanguage(LanguageEnum value) {
        this.language = value;
    }

    /**
     * Gets the value of the lost property.
     * 
     */
    public boolean isLost() {
        return lost;
    }

    /**
     * Sets the value of the lost property.
     * 
     */
    public void setLost(boolean value) {
        this.lost = value;
    }

    /**
     * Gets the value of the ranking property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Ranking }{@code >}
     *     
     */
    public JAXBElement<Ranking> getRanking() {
        return ranking;
    }

    /**
     * Sets the value of the ranking property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Ranking }{@code >}
     *     
     */
    public void setRanking(JAXBElement<Ranking> value) {
        this.ranking = value;
    }

    /**
     * Gets the value of the sessionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Sets the value of the sessionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionId(String value) {
        this.sessionId = value;
    }

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link LocalTime }
     *     
     */
    public LocalTime getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocalTime }
     *     
     */
    public void setStartTime(LocalTime value) {
        this.startTime = value;
    }

    /**
     * Gets the value of the won property.
     * 
     */
    public boolean isWon() {
        return won;
    }

    /**
     * Sets the value of the won property.
     * 
     */
    public void setWon(boolean value) {
        this.won = value;
    }

    /**
     * Gets the value of the wrongLetters property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWrongLetters() {
        return wrongLetters;
    }

    /**
     * Sets the value of the wrongLetters property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWrongLetters(String value) {
        this.wrongLetters = value;
    }

    /**
     * Gets the value of the wrongTries property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getWrongTries() {
        return wrongTries;
    }

    /**
     * Sets the value of the wrongTries property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setWrongTries(Integer value) {
        this.wrongTries = value;
    }

}

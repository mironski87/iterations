package org.proxiad.hangman.restassured;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.when;
import static org.assertj.core.api.Assertions.assertThat;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

class GameRestTest {

  @Test
  void testGetOngoingGames() {

    Response response = given().when().get("/games");
    response.then().statusCode(HttpStatus.OK.value());
    List<Game> games = response.then().extract().body().jsonPath().getList(".", Game.class);

    assertThat(games).isNotEmpty();

    for (Game game : games) {
      assertThat(game.getId()).isNotNull();
      assertThat(game.getStatistic().isLost()).isFalse();
      assertThat(game.getStatistic().isWon()).isFalse();
    }
  }

  @Test
  void testGetGame() {

    Long gameId = 3L;
    Game game = when().get("http://localhost:8080/games/{gameId}", gameId).then()
        .statusCode(HttpStatus.OK.value()).contentType(ContentType.JSON).extract().as(Game.class);

    assertThat(game).isNotNull();
    assertThat(game.getId()).isEqualTo(gameId);
  }

  @Test
  void testStartNewGame() {

    Game game = given().queryParam("type", LanguageEnum.ENGLISH)
        .contentType(MediaType.APPLICATION_JSON_VALUE).when().post("/addGame").then()
        .statusCode(HttpStatus.OK.value()).extract().as(Game.class);

    assertThat(game).isNotNull();
    assertThat(game.getHistory()).isBlank();
    assertThat(game.getWord()).isNotBlank();

    testMakeTry(game);
  }

  void testMakeTry(Game game) {

    Game gameAfterTry = given().queryParam("value", "a")
        .contentType(MediaType.APPLICATION_JSON_VALUE).when().put("/makeTry/{gameId}", game.getId())
        .then().statusCode(HttpStatus.OK.value()).extract().as(Game.class);

    assertThat(gameAfterTry).isNotNull();
    assertThat(gameAfterTry.getHistory()).isEqualTo("a");
  }
}

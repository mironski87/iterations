package org.proxiad.hangman.repository.game;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.Transactional;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
@Primary
public class GameJpaRepository implements GameCustomRepository {

  @PersistenceContext
  private EntityManager entityManager;

  @Override
  public Game create(Game game) {
    entityManager.persist(game);
    return game;
  }

  @Override
  public Game findById(Long id) {
    return entityManager.find(Game.class, id);
  }

  @Override
  public List<Game> listAll() {

    CriteriaBuilder cb = entityManager.getCriteriaBuilder();
    CriteriaQuery<Game> cq = cb.createQuery(Game.class);
    Root<Game> rootEntry = cq.from(Game.class);
    CriteriaQuery<Game> all = cq.select(rootEntry);
    return entityManager.createQuery(all).getResultList();
  }

  @Override
  public Game update(Game game) {
    return entityManager.merge(game);
  }

  @Override
  public void deleteById(Long id) {
    Game game = entityManager.find(Game.class, id);
    entityManager.remove(game);
  }
}

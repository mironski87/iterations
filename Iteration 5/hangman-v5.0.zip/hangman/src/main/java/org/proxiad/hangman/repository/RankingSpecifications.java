package org.proxiad.hangman.repository;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import org.proxiad.hangman.models.Ranking;
import org.springframework.data.jpa.domain.Specification;

public class RankingSpecifications {

  public static Specification<Ranking> hasPlayedInLastThirtyDays() {

    return (root, query, criteriaBuilder) -> {
      LocalDate thirtyDaysAgo = LocalDate.now().minus(30, ChronoUnit.DAYS);
      return criteriaBuilder.greaterThanOrEqualTo(root.get("lastPlayed"), thirtyDaysAgo);
    };
  }

  public static Specification<Ranking> getTop10Winners() {

    return (root, query, criteriaBuilder) -> {
      query.orderBy(criteriaBuilder.desc(root.get("numberOfWins")),
          criteriaBuilder.asc(root.get("fastestTime")));
      return criteriaBuilder
          .and(getPredicatesForTop10Winners(root, criteriaBuilder).toArray(new Predicate[0]));
    };
  }

  private static List<Predicate> getPredicatesForTop10Winners(Root<Ranking> root,
      CriteriaBuilder criteriaBuilder) {

    List<Predicate> predicates = new ArrayList<>();
    predicates.add(criteriaBuilder.greaterThan(root.get("numberOfWins"), 0));
    predicates.add(criteriaBuilder.isNotNull(root.get("lastPlayed")));
    return predicates;
  }
}

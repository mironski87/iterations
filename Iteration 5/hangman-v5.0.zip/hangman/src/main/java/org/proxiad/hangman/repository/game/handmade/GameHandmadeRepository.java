package org.proxiad.hangman.repository.game.handmade;

import jakarta.transaction.Transactional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.repository.game.GameCustomRepository;
import org.proxiad.hangman.service.StatisticService;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class GameHandmadeRepository implements GameCustomRepository {

  private static Connection connection;
  private static PreparedStatement statement;
  private static ResultSet result;

  private StatisticService statisticService;

  public GameHandmadeRepository(StatisticService statisticService) {
    this.statisticService = statisticService;
  }

  @Override
  public Game create(Game game) {
    createGame(game);

    return game;
  }

  @Override
  public Game findById(Long id) {
    Game game = find(id);
    return game;
  }

  @Override
  public List<Game> listAll() {
    return findAll(this.statisticService);
  }

  @Override
  public Game update(Game game) {
    updateAction(game);
    return game;
  }

  @Override
  public void deleteById(Long id) {
    delete(id);
  }

  private static void createGame(Game game) {

    connection = DBConnection.getConnection();
    String sql = "INSERT INTO GAME(WORD, HISTORY) VALUES(?, ?)";

    try {

      statement = connection.prepareStatement(sql, new String[] {"id"});

      statement.setString(1, game.getWord());
      statement.setString(2, game.getHistory());

      statement.execute();
      result = statement.getGeneratedKeys();

      if (result.next()) {
        game.setId(result.getLong(1));
      }

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  private static Game find(Long id) {

    connection = DBConnection.getConnection();
    String sql = "SELECT * FROM GAME WHERE ID = ?";

    try {

      statement = connection.prepareStatement(sql);
      statement.setLong(1, id);

      result = statement.executeQuery();

      while (result.next()) {
        Game game = new Game();

        game.setId(result.getLong("id"));
        game.setWord(result.getNString("word"));
        game.setHistory(result.getString("history"));

        return game;
      }

    } catch (SQLException e) {
      e.printStackTrace();
    }

    return null;
  }

  private static List<Game> findAll(StatisticService statisticService) {

    connection = DBConnection.getConnection();
    String sql = "SELECT * FROM GAME";
    List<Game> gamesList = new ArrayList<>();

    try {

      statement = connection.prepareStatement(sql);
      result = statement.executeQuery();

      while (result.next()) {

        Game game = new Game();

        game.setId(result.getLong(1));
        game.setWord(result.getNString(2));
        game.setHistory(result.getString(3));
        game.setStatistic(statisticService.getStatisticByGameId(game.getId()));

        gamesList.add(game);
      }

      return gamesList;

    } catch (SQLException e) {
      e.printStackTrace();
    }

    return null;
  }

  private static void updateAction(Game game) {

    connection = DBConnection.getConnection();
    String sql = "UPDATE GAME SET WORD = ?, HISTORY = ? WHERE ID = ?";

    try {

      statement = connection.prepareStatement(sql);
      statement.setString(1, game.getWord());
      statement.setString(2, game.getHistory());
      statement.setLong(3, game.getId());

      statement.execute();

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  private static void delete(Long id) {

    connection = DBConnection.getConnection();
    String sql = "DELETE FROM GAME WHERE ID = ?";

    try {

      statement = connection.prepareStatement(sql);
      statement.setLong(1, id);
      statement.execute();

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}

package org.proxiad.hangman.service;

import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.GameDTO;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class MappingService {

  private GameService gameService;

  public MappingService(GameService gameService) {
    this.gameService = gameService;
  }

  public GameDTO startNewGame(LanguageEnum language, String sessionId) {
    return convertDataIntoDTO(gameService.startNewGame(language, sessionId));
  }

  public GameDTO getGameById(Long id) {
    return convertDataIntoDTO(gameService.getGame(id));
  }

  public GameDTO makeGuess(Long gameId, char letter, String sessionId) {
    return convertDataIntoDTO(gameService.makeGuess(gameId, letter, sessionId));
  }

  public GameDTO wonOrLost(GameDTO dto) {
    return convertDataIntoDTO(gameService.wonOrLost(dto));
  }

  private GameDTO convertDataIntoDTO(Game game) {

    Statistic statistic = game.getStatistic();
    GameDTO dto = new GameDTO();

    dto.setGameId(game.getId());
    dto.setMaskedWord(game.getWord(), game.getHistory());
    dto.setWrongTriesChars(statistic.getWrongLetters());
    dto.setWrongTries(statistic.getWrongTries());
    dto.setLanguage(statistic.getLanguage());

    return dto;
  }
}

package org.proxiad.hangman.service;

import java.time.LocalTime;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.repository.StatisticRepository;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class StatisticService {

  private StatisticRepository statisticRepo;
  private RankingService rankingService;

  public StatisticService(StatisticRepository repo, RankingService rankingService) {
    this.statisticRepo = repo;
    this.rankingService = rankingService;
  }

  public Statistic addStatistic(LanguageEnum language, String sessionId, Game game) {

    Statistic statistic = new Statistic();

    statistic.setSessionId(sessionId);
    statistic.setLanguage(language);
    statistic.setGame(game);

    statisticRepo.save(statistic);
    return statistic;
  }

  public Statistic getStatisticByGameId(Long id) {
    return statisticRepo.findByGameId(id);
  }

  public Statistic getStatistic(Long id) {
    return statisticRepo.findById(id).orElse(null);
  }

  public List<Statistic> getAllStatistics() {
    return statisticRepo.findAll();
  }

  public void finalUpdateStatistic(Game game, boolean isWon) {

    Statistic statistic = game.getStatistic();

    statistic.setWon(isWon);
    statistic.setLost(!isWon);
    statistic.setEndTime(LocalTime.now());
    statistic.setRanking(rankingService.addRanking(statistic));

    statisticRepo.save(statistic);

    rankingService.addRanking(statistic);
  }

  public void wrongCharAdd(Game game, char letter) {

    Statistic statistic = game.getStatistic();

    StringBuilder builder = new StringBuilder("" + statistic.getWrongLetters());
    builder.append(letter);
    statistic.setWrongLetters(builder.toString());

    statistic.setWrongTries(statistic.getWrongTries() + 1);
    statisticRepo.save(statistic);
  }

  public void deleteStatistic(Long id) {
    statisticRepo.deleteById(id);
  }
}

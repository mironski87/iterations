package org.proxiad.hangman.models;

import lombok.Data;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Data
public class GameDTO {

  private long gameId;
  private String maskedWord;
  private String wrongTriesChars;
  private int wrongTries;
  private LanguageEnum language;

  public void setMaskedWord(String word, String history) {
    this.maskedWord = makeMaskedWord(word, history);
  }

  public boolean isGameWon() {

    for (Character letter : this.maskedWord.toCharArray()) {
      if (letter == '*') {
        return false;
      }
    }

    return true;
  }

  public boolean isGameLost() {
    return this.wrongTries >= 6;
  }


  private static String makeMaskedWord(String word, String history) {

    StringBuilder builder = new StringBuilder("");

    for (Character wordChar : word.toCharArray()) {

      boolean isGuessRight = false;

      for (Character historyChar : history.toCharArray()) {

        if (wordChar.equals(historyChar)) {

          isGuessRight = true;
          break;
        }
      }

      char charToAppend = isGuessRight ? wordChar : '*';
      builder.append(charToAppend);
    }

    return builder.toString();
  }
}

package org.proxiad.hangman.repository.game;

import java.util.List;
import org.proxiad.hangman.models.Game;

public interface GameCustomRepository {

  Game create(Game game);

  Game findById(Long id);

  List<Game> listAll();

  Game update(Game game);

  void deleteById(Long id);
}

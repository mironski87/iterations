package org.proxiad.hangman.repository.game;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.Transactional;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.proxiad.hangman.models.Game;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public class GameCriteriaRepository implements GameCustomRepository {

  private SessionFactory sessionFactory;

  public GameCriteriaRepository(SessionFactory sessionFactory) {
    this.sessionFactory = sessionFactory;
  }

  @Override
  public Game create(Game game) {

    Session session = sessionFactory.getCurrentSession();
    session.persist(game);
    return game;
  }

  @Override
  public Game findById(Long id) {

    Session session = sessionFactory.getCurrentSession();
    return session.find(Game.class, id);

    // CriteriaBuilder builder = session.getCriteriaBuilder();
    // CriteriaQuery<Game> cQuery = builder.createQuery(Game.class);
    // Root<Game> root = cQuery.from(Game.class);
    //
    // cQuery.where(builder.equal(root.get("id"), id));
    // Query<Game> query = session.createQuery(cQuery);
    //
    // return query.getSingleResult();
  }

  @Override
  public List<Game> listAll() {

    Session session = sessionFactory.getCurrentSession();

    CriteriaBuilder builder = session.getCriteriaBuilder();
    CriteriaQuery<Game> cQuery = builder.createQuery(Game.class);
    Root<Game> root = cQuery.from(Game.class);

    cQuery.select(root);
    Query<Game> query = session.createQuery(cQuery);

    return query.getResultList();
  }

  @Override
  public Game update(Game game) {

    Session session = sessionFactory.getCurrentSession();
    return session.merge(game);
  }

  @Override
  public void deleteById(Long id) {

    Session session = sessionFactory.getCurrentSession();
    session.remove(findById(id));
  }
}

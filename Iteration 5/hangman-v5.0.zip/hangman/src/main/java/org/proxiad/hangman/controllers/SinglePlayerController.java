package org.proxiad.hangman.controllers;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.proxiad.hangman.models.GameDTO;
import org.proxiad.hangman.service.MappingService;
import org.proxiad.hangman.service.RankingService;
import org.proxiad.hangman.utility.LatinCyrillicInputValidator;
import org.proxiad.hangman.validator.models.Input;
import org.proxiad.hangman.validator.models.Language;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SinglePlayerController {

  private MappingService mappingService;
  private RankingService rankingService;

  public SinglePlayerController(MappingService mappingService, RankingService rankingService) {
    this.mappingService = mappingService;
    this.rankingService = rankingService;
  }

  @PostMapping("/startNewGame")
  public String startNewGame(@Valid @ModelAttribute("languageValid") Language languageValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    if (bindingResult.hasErrors()) {
      model.addAttribute("languageValidator", new Language());
      model.addAttribute("errors", bindingResult);
      return "index";
    }

    GameDTO game = mappingService.startNewGame(languageValidator.getType(), session.getId());
    modifyCommonModel(model, game);
    return "game";
  }

  @PostMapping("/makeTry/{gameId}")
  public String makeTry(@PathVariable Long gameId,
      @Valid @ModelAttribute("inputValidator") Input inputValidator, BindingResult bindingResult,
      HttpSession session, Model model) {

    GameDTO game = mappingService.getGameById(gameId);
    char letter = inputValidator.getValue().charAt(0);

    if (bindingResult.hasErrors()
        || !LatinCyrillicInputValidator.isValid(game.getLanguage(), letter)) {

      modifyCommonModel(model, game);
      model.addAttribute("errors", bindingResult);
      return "game";
    }

    game = mappingService.makeGuess(gameId, letter, session.getId());

    if (game.isGameWon() || game.isGameLost()) {
      game = mappingService.wonOrLost(game);

      model.addAttribute("topTenEver", rankingService.getTopTenWinnersEver());
      model.addAttribute("topTenInThirtyDays",
          rankingService.getTopTenFastestWinnersInThirtyDays());
      model.addAttribute("languageValidator", new Language());
      model.addAttribute("game", game);
      return "result";
    }

    modifyCommonModel(model, game);
    return "game";
  }

  private static void modifyCommonModel(Model model, GameDTO game) {
    model.addAttribute("game", game);
    model.addAttribute("inputValidator", new Input());
    model.addAttribute("languageValidator", new Language());
  }
}

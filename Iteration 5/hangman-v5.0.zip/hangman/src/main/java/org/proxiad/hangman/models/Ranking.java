package org.proxiad.hangman.models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Table(name = "ranking")
public class Ranking {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", columnDefinition = "bigint")
  private Long id;

  @Column(name = "session_id", length = 35)
  private String sessionId;

  @Column(name = "number_of_wins")
  private Integer numberOfWins;

  @Column(name = "number_of_losses")
  private Integer numberOfLosses;

  @Column(name = "fastest_time")
  private Time fastestTime;

  @Column(name = "last_played")
  private LocalDate lastPlayed;

  @OneToMany(mappedBy = "ranking")
  private List<Statistic> statistics;

  public Ranking() {
    this.sessionId = "";
    this.numberOfWins = 0;
    this.numberOfLosses = 0;
    this.fastestTime = new Time(1L);
    this.lastPlayed = LocalDate.now();
  }
}

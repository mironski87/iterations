package org.proxiad.hangman.controllers;

import jakarta.servlet.http.HttpSession;
import org.proxiad.hangman.service.RankingService;
import org.proxiad.hangman.validator.models.Language;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationController {

  private RankingService rankingService;

  public ApplicationController(RankingService rankingService) {
    this.rankingService = rankingService;
  }

  @GetMapping("/")
  public String getIndex(Model model, HttpSession session) {

    model.addAttribute("playerRanking", rankingService.findBySessionId(session.getId()));
    model.addAttribute("languageValidator", new Language());
    return "index";
  }
}

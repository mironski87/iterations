package org.proxiad.hangman.service;

import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.GameDTO;
import org.proxiad.hangman.repository.game.handmade.GameHandmadeRepository;
import org.proxiad.hangman.utility.RandomWordUtil;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class GameService {

  private GameHandmadeRepository gameRepository;
  private StatisticService statisticService;

  public GameService(GameHandmadeRepository gameRepository, StatisticService statisticService) {
    this.gameRepository = gameRepository;
    this.statisticService = statisticService;
  }

  public Game startNewGame(LanguageEnum language, String sessionId) {

    Game game = new Game();
    game.setWord(RandomWordUtil.generate(language));
    System.out.println(game.getWord());

    game = gameRepository.create(game);
    game.setStatistic(statisticService.addStatistic(language, sessionId, game));
    return game;
  }

  public Game getGame(Long id) {
    Game game = gameRepository.findById(id);
    game.setStatistic(statisticService.getStatisticByGameId(id));
    return game;
  }

  public Game makeGuess(Long id, char letter, String sessionId) {

    Game game = getGame(id);

    if (isInvalidGameTry(game, sessionId)) {
      throw new IllegalArgumentException();
    }

    if (doGameHistoryContainsThisLetter(game, letter)) {
      return game;
    }

    if (isLetterWrong(game, letter)) {
      statisticService.wrongCharAdd(game, letter);
    }

    buildHistory(game, letter);
    gameRepository.update(game);

    return game;
  }

  public Game wonOrLost(GameDTO dto) {

    Game game = getGame(dto.getGameId());
    statisticService.finalUpdateStatistic(game, dto.isGameWon());
    return game;
  }

  private static boolean isInvalidGameTry(Game game, String sessionId) {

    return (!game.getStatistic().getSessionId().equals(sessionId))
        || (game.getStatistic().isWon() || game.getStatistic().isLost());
  }

  private static boolean doGameHistoryContainsThisLetter(Game game, char letter) {

    for (Character letterItem : game.getHistory().toCharArray()) {
      if (letterItem == letter) {
        return true;
      }
    }

    return false;
  }

  private static boolean isLetterWrong(Game game, char letter) {

    for (Character wordChar : game.getWord().toCharArray()) {
      if (wordChar == letter) {
        return false;
      }
    }

    return true;
  }

  private static void buildHistory(Game game, char letter) {

    StringBuilder builder = new StringBuilder(game.getHistory());
    builder.append(letter);
    game.setHistory(builder.toString());
  }
}

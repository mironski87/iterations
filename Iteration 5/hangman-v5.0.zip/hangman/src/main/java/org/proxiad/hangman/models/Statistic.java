package org.proxiad.hangman.models;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.time.LocalTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Entity
@Data
@AllArgsConstructor
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
@Table(name = "statistic")
public class Statistic {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", columnDefinition = "bigint")
  private Long id;

  @Column(name = "session_id", length = 35)
  private String sessionId;

  @Column(name = "start_time")
  private LocalTime startTime;

  @Column(name = "end_time")
  private LocalTime endTime;

  @Column(name = "is_won")
  private boolean isWon;

  @Column(name = "is_lost")
  private boolean isLost;

  @Enumerated(EnumType.STRING)
  @Column(name = "language")
  private LanguageEnum language;

  @Column(name = "wrong_tries", columnDefinition = "tinyint")
  private Integer wrongTries;

  @Column(name = "wrong_letters", length = 10)
  private String wrongLetters;

  @OneToOne
  @JoinColumn(name = "game_id")
  private Game game;

  @ManyToOne
  @JoinColumn(name = "ranking_id")
  private Ranking ranking;

  public Statistic() {
    this.sessionId = "";
    this.startTime = LocalTime.now();
    this.endTime = LocalTime.now();
    this.isWon = false;
    this.isLost = false;
    this.language = null;
    this.wrongTries = 0;
    this.wrongLetters = "";
  }
}

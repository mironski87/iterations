package org.proxiad.hangman.validator.language;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({METHOD, FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(validatedBy = CustomLanguageConstraint.class)
public @interface CustomLanguageValidator {

  String message() default "Must be ENGLISH or BULGARIAN.";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}

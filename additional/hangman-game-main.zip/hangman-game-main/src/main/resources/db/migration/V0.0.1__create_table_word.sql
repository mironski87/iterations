CREATE TABLE game_word
  (
     `id`      INT NOT NULL AUTO_INCREMENT,
     `content` VARCHAR(15),
     PRIMARY KEY (`id`)
  )
AUTO_INCREMENT=1;

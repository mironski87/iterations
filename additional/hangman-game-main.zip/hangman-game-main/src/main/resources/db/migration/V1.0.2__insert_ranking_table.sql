INSERT INTO game_ranking (gamer_name,total_wins) VALUES

           ('noob',0),
           ('easy',1),
           ('all_in',5),
           ('just4fun',2),
           ('newbie',4),
           ('the_punisher',2),
           ('no_name@',1),
           ('bizzy',0),
           ('zigzag',3),
           ('machine_gun',1),
           ('^^phantom',2),
           ('xpert',8),
           ('mac',2);
        
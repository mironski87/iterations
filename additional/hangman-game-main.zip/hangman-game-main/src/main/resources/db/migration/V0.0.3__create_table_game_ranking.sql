CREATE TABLE game_ranking
  (
     `gamer_name` VARCHAR(30),
     `total_wins` INT,
     PRIMARY KEY (`gamer_name`)
  );
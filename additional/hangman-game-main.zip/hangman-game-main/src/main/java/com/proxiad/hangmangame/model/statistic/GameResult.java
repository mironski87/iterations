package com.proxiad.hangmangame.model.statistic;

public enum GameResult {
  WIN,
  LOSS
}

package com.proxiad.hangmangame.model.security;

public interface Permissions {
  String STAT_CREATE = "stat:create";
}

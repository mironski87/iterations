export const StatInputStyle = {
  marginTop: "40px",
  outline: "none",
  border: "none",
  fontSize: "30px",
  fontFamily: "Lucida Console",
};

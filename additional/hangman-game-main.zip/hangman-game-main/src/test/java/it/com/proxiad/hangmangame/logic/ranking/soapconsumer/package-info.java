@javax.xml.bind.annotation.XmlSchema(namespace = "http://ranking.logic.hangmangame.proxiad.com/")
package it.com.proxiad.hangmangame.logic.ranking.soapconsumer;

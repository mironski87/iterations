package org.proxiad.hangman.dto.game;

import java.util.List;
import org.proxiad.hangman.validator.language.LanguageEnum;

public interface GameMappingService {

  GameDTO getGameById(String encodedId);

  List<GameDTO> getOngoingGames();

  GameDTO startNewGame(LanguageEnum language, String sessionId);

  GameDTO makeGuess(String encodedId, char letter, String sessionId);
}

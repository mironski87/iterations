package org.proxiad.hangman.dto.game;

import lombok.Data;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Data
public class GameDTO {

  private String id;
  private String maskedWord;
  private String wrongTriesChars;
  private int wrongTries;
  private LanguageEnum language;
  private boolean isWon;
  private boolean isLost;
}

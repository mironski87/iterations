package org.proxiad.hangman.service;

import java.time.LocalTime;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.repository.StatisticRepository;
import org.proxiad.hangman.service.interfaces.RankingService;
import org.proxiad.hangman.service.interfaces.StatisticService;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class StatisticServiceImpl implements StatisticService {

  private StatisticRepository statisticRepo;
  private RankingService rankingService;

  public StatisticServiceImpl(StatisticRepository repo, RankingService rankingService) {
    this.statisticRepo = repo;
    this.rankingService = rankingService;
  }

  @Override
  public Statistic addStatistic(LanguageEnum language, String sessionId, Game game) {

    Statistic statistic = new Statistic();

    statistic.setSessionId(sessionId);
    statistic.setLanguage(language);
    statistic.setGame(game);

    statisticRepo.save(statistic);
    return statistic;
  }

  @Override
  public Statistic getStatisticByGameId(Long id) {

    Statistic statistic = statisticRepo.findByGameId(id);
    statistic.setRanking(rankingService.findBySessionId(statistic.getSessionId()));
    return statistic;
  }

  @Override
  public Statistic getStatistic(Long id) {

    Statistic statistic = statisticRepo.findById(id).orElse(null);
    statistic.setRanking(rankingService.findBySessionId(statistic.getSessionId()));
    return statistic;
  }

  @Override
  public List<Statistic> getAllStatistics() {
    return statisticRepo.findAll();
  }

  @Override
  public void finalUpdateStatistic(Game game, boolean isWon) {

    Statistic statistic = game.getStatistic();

    statistic.setWon(isWon);
    statistic.setLost(!isWon);
    statistic.setEndTime(LocalTime.now());
    statistic.setRanking(rankingService.addRanking(statistic));

    statisticRepo.save(statistic);

    rankingService.addRanking(statistic);
  }

  @Override
  public void wrongCharAdd(Game game, char letter) {

    Statistic statistic = game.getStatistic();

    StringBuilder builder = new StringBuilder("" + statistic.getWrongLetters());
    builder.append(letter);
    statistic.setWrongLetters(builder.toString());

    statistic.setWrongTries(statistic.getWrongTries() + 1);
    statisticRepo.save(statistic);
  }

  @Override
  public void deleteStatistic(Long id) {
    statisticRepo.deleteById(id);
  }
}

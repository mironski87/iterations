package org.proxiad.hangman.repository;

import jakarta.transaction.Transactional;
import java.util.List;
import org.proxiad.hangman.models.Ranking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public interface RankingRepository extends JpaRepository<Ranking, Long> {

  Ranking findBySessionId(String sessionId);

  @Query(value = "SELECT * FROM RANKING ORDER BY NUMBER_OF_WINS DESC LIMIT 10;", nativeQuery = true)
  List<Ranking> getTopTenWinners();

  @Query(value = "SELECT * FROM RANKING WHERE LAST_PLAYED >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
      + "ORDER BY NUMBER_OF_WINS DESC, FASTEST_TIME ASC LIMIT 10;", nativeQuery = true)
  List<Ranking> getTopTenFastestWinnersIn30Days();
}

package org.proxiad.hangman.service.interfaces;

import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.validator.language.LanguageEnum;

public interface StatisticService {

  Statistic addStatistic(LanguageEnum language, String sessionId, Game game);

  Statistic getStatisticByGameId(Long id);

  Statistic getStatistic(Long id);

  List<Statistic> getAllStatistics();

  void finalUpdateStatistic(Game game, boolean isWon);

  void wrongCharAdd(Game game, char letter);

  void deleteStatistic(Long id);
}

package org.proxiad.hangman.dto.game;

import java.util.List;
import java.util.stream.Collectors;
import org.proxiad.hangman.encoder.IdEncoder;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.service.interfaces.GameService;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class GameMappingServiceImpl implements GameMappingService {

  private GameService gameService;
  private IdEncoder encoder;

  public GameMappingServiceImpl(GameService gameService, IdEncoder encoder) {
    this.gameService = gameService;
    this.encoder = encoder;
  }

  @Override
  public GameDTO getGameById(String encodedId) {
    return convertDataIntoDTO(gameService.getGame(encoder.decode(encodedId)));
  }

  @Override
  public List<GameDTO> getOngoingGames() {

    List<Game> ongoingGames = gameService.listOngoingGames();
    return ongoingGames.stream().map(this::convertDataIntoDTO).collect(Collectors.toList());
  }

  @Override
  public GameDTO startNewGame(LanguageEnum language, String sessionId) {
    return convertDataIntoDTO(gameService.startNewGame(language, sessionId));
  }

  @Override
  public GameDTO makeGuess(String encodedId, char letter, String sessionId) {
    return convertDataIntoDTO(gameService.makeGuess(encoder.decode(encodedId), letter, sessionId));
  }

  private GameDTO convertDataIntoDTO(Game game) {

    Statistic statistic = game.getStatistic();
    GameDTO dto = new GameDTO();

    dto.setId(encoder.encode(game.getId()));
    dto.setMaskedWord(generateMaskedWord(game));
    dto.setWrongTriesChars(statistic.getWrongLetters());
    dto.setWrongTries(statistic.getWrongTries());
    dto.setLanguage(statistic.getLanguage());
    dto.setWon(game.getStatistic().isWon());
    dto.setLost(game.getStatistic().isLost());

    return dto;
  }

  private static String generateMaskedWord(Game game) {

    StringBuilder builder = new StringBuilder("");

    String word = game.getWord();
    String history = game.getHistory();

    for (Character wordChar : word.toCharArray()) {

      boolean isGuessRight = false;

      for (Character historyChar : history.toCharArray()) {

        if (wordChar.equals(historyChar)) {

          isGuessRight = true;
          break;
        }
      }

      char charToAppend = isGuessRight ? wordChar : '*';
      builder.append(charToAppend);
    }

    return builder.toString();
  }
}

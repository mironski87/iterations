package org.proxiad.hangman.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.List;
import org.proxiad.hangman.dto.game.GameDTO;
import org.proxiad.hangman.dto.game.GameMappingService;
import org.proxiad.hangman.validator.models.Input;
import org.proxiad.hangman.validator.models.Language;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class GameApi {

  private GameMappingService mappingService;

  public GameApi(GameMappingService mappingService) {
    this.mappingService = mappingService;
  }

  @GetMapping(value = "/game", produces = APPLICATION_JSON_VALUE)
  public List<GameDTO> getOngoingGames() {
    return mappingService.getOngoingGames();
  }

  @GetMapping(value = "/game/{gameId}", produces = APPLICATION_JSON_VALUE)
  public GameDTO getGame(@PathVariable String gameId) {
    return mappingService.getGameById(gameId);
  }

  @PostMapping(value = "/game", produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  public GameDTO addNewGame(@Valid @RequestBody Language language, HttpSession session) {
    return mappingService.startNewGame(language.getType(), session.getId());
  }

  @PutMapping(value = "/game/{gameId}", produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  public GameDTO makeTry(@PathVariable String gameId, @Valid @RequestBody Input input,
      HttpSession session) {
    return mappingService.makeGuess(gameId, input.getValue().charAt(0), session.getId());
  }
}

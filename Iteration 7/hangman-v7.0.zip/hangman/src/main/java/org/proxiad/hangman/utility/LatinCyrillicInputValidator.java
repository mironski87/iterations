package org.proxiad.hangman.utility;

import org.proxiad.hangman.validator.language.LanguageEnum;

public class LatinCyrillicInputValidator {

  private LatinCyrillicInputValidator() {}

  public static boolean isValid(LanguageEnum language, char letter) {

    if (language == LanguageEnum.values()[1] && (letter < 'a' || letter > 'z')) {
      return false;
    }

    if (language == LanguageEnum.values()[0] && (letter < 'а' || letter > 'я')) {
      return false;
    }

    return true;
  }
}

import { Form } from "react-bootstrap";

function EnglishRadioMain({ onChange }) {

    return (
        <Form.Check
            type='radio'
            name='type'
            label='English'
            value='ENGLISH'
            onChange={onChange}
            defaultChecked
        />
    );
}

export default EnglishRadioMain;
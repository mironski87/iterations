
function EnglishLeftTries({ game }) {

    return (
        <div>
            <h1>{game.maskedWord}</h1>

            <h2>{game.wrongTriesChars}</h2>

            <h2>You left {6 - game.wrongTries} tries.</h2>
        </div>
    );
}

export default EnglishLeftTries;
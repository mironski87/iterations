import { Form } from "react-bootstrap";
import EnglishLeftTries from "./left-tries-render/EnglishLeftTries"
import EnglishSubmitButton from "./submit_button/EnglishSubmitButton"

function EnglishForm({ onSubmit, game }) {

    return (
        <div>
            <EnglishLeftTries game={game} />

            <Form onSubmit={onSubmit}>

                <Form.Group controlId='letterTry'>
                    <Form.Control type='text' maxLength='1' autoFocus />
                </Form.Group>

                <EnglishSubmitButton />
            </Form>
        </div>
    );
}

export default EnglishForm;
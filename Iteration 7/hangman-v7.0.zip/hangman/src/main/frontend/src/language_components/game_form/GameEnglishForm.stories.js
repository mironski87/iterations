import React from "react";
import EnglishForm from "./EnglishForm";

const game = {
    id: "test",
    maskedWord: "*****",
    wrongTriesChars: "abv",
    wrongTries: 3,
    language: "ENGLISH"
}

export default {
    title: "GameEnglishForm",
    component: EnglishForm
};

const Template = (args) => <EnglishForm {...args} />

export const Default = Template.bind({game});
Default.args = {game};
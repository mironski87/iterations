import { Form } from "react-bootstrap";

function EnglishRadioSecondary({ onChange }) {

    return (
        <Form.Check
            type='radio'
            name='type'
            label='English'
            value='ENGLISH'
            onChange={onChange}
        />
    );
}

export default EnglishRadioSecondary;
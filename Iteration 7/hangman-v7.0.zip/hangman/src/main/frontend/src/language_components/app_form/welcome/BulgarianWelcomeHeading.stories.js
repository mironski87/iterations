import React from "react";
import BulgarianWelcomeHeading from "./BulgarianWelcomeHeading";

export default {
    title: "BulgarianWelcomeHeading",
    component: BulgarianWelcomeHeading
};

const Template = (args) => <BulgarianWelcomeHeading {...args} />

export const Default = Template.bind({});
Default.args = {};
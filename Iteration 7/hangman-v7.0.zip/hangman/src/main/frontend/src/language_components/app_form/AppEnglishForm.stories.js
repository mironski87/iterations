import React from "react";
import EnglishForm from "./EnglishForm";

export default {
    title: "AppEnglishForm",
    component: EnglishForm
};

const Template = (args) => <EnglishForm {...args} />

export const Default = Template.bind({});
Default.args = {};
function BulgarianWelcomeHeading() {

    return (
        <h1>Добре дошли в Бесеница!</h1>
    );
}

export default BulgarianWelcomeHeading;
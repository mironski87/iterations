import { Form } from "react-bootstrap";
import BulgarianLeftTries from "./left-tries-render/BulgarianLeftTries"
import BulgarianSubmitButton from "./submit_button/BulgarianSubmitButton"

function BulgarianForm({ onSubmit, game }) {

    return (
        <div>
            <BulgarianLeftTries game={game} />

            <Form onSubmit={onSubmit}>

                <Form.Group controlId='letterTry'>
                    <Form.Control type='text' maxLength='1' autoFocus />
                </Form.Group>

                <BulgarianSubmitButton />
            </Form>
        </div>
    );
}

export default BulgarianForm;
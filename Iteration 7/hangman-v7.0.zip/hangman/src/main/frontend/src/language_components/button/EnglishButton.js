import { Button } from "react-bootstrap";

function EnglishButton() {

    return (
        <Button variant='primary' type='submit'>
            Start new game
        </Button>
    );
}

export default EnglishButton;
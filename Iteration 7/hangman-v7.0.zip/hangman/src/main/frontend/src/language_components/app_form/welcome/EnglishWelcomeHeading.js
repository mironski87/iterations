function EnglishWelcomeHeading() {

    return (
        <h1>Welcome to Hangman!</h1>
    );
}

export default EnglishWelcomeHeading;
import { Container } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom';
import useSwr from 'swr';

import EnglishForm from './language_components/game_form/EnglishForm';
import BulgarianForm from './language_components/game_form/BulgarianForm';

function GameEnglishPage() {

    const { gameId } = useParams();
    const navigate = useNavigate();

    const { data: game, error, isLoading, mutate } = useSwr(`http://localhost:8080/game/${gameId}`, async (url) => {
        const response = await fetch(url);
        return await response.json();
    });

    async function submitAction(e) {

        e.preventDefault();

        const value = e.target.letterTry.value;

        await fetch(`http://localhost:8080/game/${gameId}`, {
            method: 'PUT',
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ value })
        });

        await mutate();

        e.target.letterTry.value = "";
    };

    if (isLoading) return <div>Loading game...</div>
    if (error) return <div>Error during loading game...</div>
    if (game.won || game.lost) navigate(`/result/${gameId}`);
    
    return (
        <Container>
            {isEnglish(game)
            ? <EnglishForm onSubmit={submitAction} game={game} />
            : <BulgarianForm onSubmit={submitAction} game={game} />}
        </Container>
    );
}

function isEnglish(game) {
    return game.language === "ENGLISH";
}

export default GameEnglishPage;
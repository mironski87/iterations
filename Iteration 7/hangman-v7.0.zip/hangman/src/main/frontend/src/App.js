import { useState } from 'react';
import { Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

import EnglishForm from "./language_components/app_form/EnglishForm";
import BulgarianForm from "./language_components/app_form/BulgarianForm";

function App() {

  const navigate = useNavigate();
  const [isEnglish, setIsEnglish] = useState(true);

  function onChange(e) {
    setIsEnglish(e.target.value === 'ENGLISH');
  }

  async function startNewGame(e) {

    e.preventDefault();

    const response = await fetch(`http://localhost:8080/game`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ type: isEnglish ? 'ENGLISH' : 'BULGARIAN' })
    });

    const game = await response.json();

    if (response.status === 200 && game) {
      console.log(game.id);
      navigate(`/game/${game.id}`);
    }
  };

  return (
    <Container>
      {isEnglish
        ? <EnglishForm onSubmit={startNewGame} onChange={onChange} />
        : <BulgarianForm onSubmit={startNewGame} onChange={onChange} />}
    </Container>
  );
}

export default App;
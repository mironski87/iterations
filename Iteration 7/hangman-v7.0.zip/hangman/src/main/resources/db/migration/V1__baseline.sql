CREATE TABLE game (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  history varchar(40) DEFAULT NULL,
  word varchar(30) DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE ranking (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  fastest_time time DEFAULT NULL,
  last_played date DEFAULT NULL,
  number_of_losses int(11) DEFAULT NULL,
  number_of_wins int(11) DEFAULT NULL,
  session_id varchar(35) DEFAULT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE statistic (
  id bigint(20) NOT NULL AUTO_INCREMENT,
  end_time time DEFAULT NULL,
  is_lost bit(1) DEFAULT NULL,
  is_won bit(1) DEFAULT NULL,
  language varchar(255) DEFAULT NULL,
  session_id varchar(35) DEFAULT NULL,
  start_time time DEFAULT NULL,
  wrong_letters varchar(10) DEFAULT NULL,
  wrong_tries tinyint(4) DEFAULT NULL,
  game_id bigint(20) DEFAULT NULL,
  ranking_id bigint(20) DEFAULT NULL,
  PRIMARY KEY (id)
);

ALTER TABLE statistic ADD CONSTRAINT game_id FOREIGN KEY (game_id) REFERENCES game (id);
ALTER TABLE statistic ADD CONSTRAINT ranking_id FOREIGN KEY (ranking_id) REFERENCES ranking (id);
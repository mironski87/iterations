package servlets.counts;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bg.proxiad.demo.ReqCountingFilter;

@WebServlet("/count-all-requests")
public class GetAllRequestsMadeServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

    Long counter = (Long) req.getServletContext().getAttribute(ReqCountingFilter.COUNTER_ATTR);
    resp.getWriter().write("<html><body> All requests made are: " + counter + "</html></body>");
    resp.flushBuffer();
  }
}

package servlets.counts;

import bg.proxiad.demo.ConfigureSessionCounterListener;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/count-my-requests")
public class GetSessionRequestsMadeServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {

    Long counter = (Long) req.getServletContext()
        .getAttribute(ConfigureSessionCounterListener.SESSION_COUNTER_ATTR);
    resp.getWriter().write("<html><body> Only my requests made are: " + counter + "</html></body>");
    resp.flushBuffer();
  }
}

package servlets.greetings;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// @WebServlet("/say-hello-my-way")
// @WebServlet(urlPatterns = {"/say-hello-my-way"},
// initParams = {@WebInitParam(name = "greetings", value = "Hello")})
public class SayHelloMyWayServlet extends HttpServlet {

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    String greetings = getInitParameter("greetings");
    String name = req.getParameter("name");

    resp.setHeader("content-type", "text/html;charset=utf-8");
    resp.getWriter().write("<html><body>" + greetings + ", " + name + "</html></body>");
    resp.flushBuffer();
  }
}

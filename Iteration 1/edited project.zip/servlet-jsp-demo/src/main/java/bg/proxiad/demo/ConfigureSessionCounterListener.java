package bg.proxiad.demo;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class ConfigureSessionCounterListener implements HttpSessionListener {

  public static final String SESSION_COUNTER_ATTR = "sessionCounter";

  private static Map<String, Long> sessionCounter = new HashMap<String, Long>();

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    se.getSession().getServletContext().setAttribute(SESSION_COUNTER_ATTR, Long.valueOf(0L));

  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    sessionCounter.remove(se.getSession().getId());
  }

  public static Map<String, Long> getSessionCounter() {
    return sessionCounter;
  }

}

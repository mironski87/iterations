package service;

import models.Game;
import models.Letter;
import repository.GameRepository;
import utility.RandomWordUtil;

public class HangmanServiceImpl implements HangmanService {

  @Override
  public Game startNewGame(String sessionId) {

    if (GameRepository.getGameById(sessionId) != null) {
      deleteGame(sessionId);
    }

    Game game = new Game(sessionId, RandomWordUtil.generate());
    GameRepository.addGame(game);

    return game;
  }

  @Override
  public Game getGame(String gameId) {
    return GameRepository.getGameById(gameId);
  }

  @Override
  public Game makeGuess(String gameId, Letter letter) {

    Game game = GameRepository.getGameById(gameId);

    if (doGameTriesContainsThisLetter(game, letter)) {
      return game;
    }

    boolean doWordContainsTheLetter = doWordContains(game, letter);

    letter.setCorrect(doWordContainsTheLetter);
    game.getAlphabetsPicked().add(letter);

    if (!doWordContainsTheLetter) {
      game.addTry();
    }

    GameRepository.updateGame(game);
    return game;
  }

  @Override
  public void deleteGame(String gameId) {

    Game game = GameRepository.getGameById(gameId);
    GameRepository.deleteGame(game);
  }

  // checks if this word was already given as pick
  private boolean doGameTriesContainsThisLetter(Game game, Letter letter) {

    for (Letter letterItem : game.getAlphabetsPicked()) {
      if (letterItem.getLetter() == letter.getLetter()) {
        return true;
      }
    }

    return false;
  }

  // checks if the given letter is inside the game's word
  // if so: changes word's letter to true
  private boolean doWordContains(Game game, Letter letter) {

    boolean doContains = false;

    for (Letter item : game.getWord()) {
      if (item.getLetter() == letter.getLetter()) {

        item.setCorrect(true);
        doContains = true;
      }
    }

    return doContains;
  }
}

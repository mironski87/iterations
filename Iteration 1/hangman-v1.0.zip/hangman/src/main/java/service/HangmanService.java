package service;

import models.Game;
import models.Letter;

public interface HangmanService {

  public Game startNewGame(String sessionId);

  public Game getGame(String gameId);

  public Game makeGuess(String gameId, Letter letter);

  public void deleteGame(String gameId);
}

package models;

import java.util.ArrayList;
import java.util.List;

public class Game {

  private String gameId;
  private List<Letter> word;
  private List<Letter> alphabetsPicked;
  private int triesMade;

  public Game(String gameId, List<Letter> word) {

    this.gameId = gameId;
    this.word = word;
    this.triesMade = 0;
    alphabetsPicked = new ArrayList<Letter>();
  }

  public String getGameId() {
    return gameId;
  }

  public void setGameId(String gameId) {
    this.gameId = gameId;
  }

  public List<Letter> getWord() {
    return word;
  }

  public void setWord(List<Letter> word) {
    this.word = word;
  }

  public List<Letter> getAlphabetsPicked() {
    return alphabetsPicked;
  }

  public void setAlphabetsPicked(List<Letter> alphabetsPicked) {
    this.alphabetsPicked = alphabetsPicked;
  }

  public int getTriesMade() {
    return this.triesMade;
  }

  public void addTry() {
    this.triesMade++;
  }
}

package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Game;
import models.Letter;
import service.HangmanService;
import service.HangmanServiceImpl;

@WebServlet("/startNewGame")
public class StartNewGameServlet extends HttpServlet {

  private HangmanService service = new HangmanServiceImpl();

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    Game game = service.startNewGame(req.getSession().getId());
    wordPrintInConsole(game);

    getServletContext().getRequestDispatcher("/WEB-INF/jsp/game.jsp").forward(req, resp);
  }

  private void wordPrintInConsole(Game game) {

    for (Letter letter : game.getWord()) {
      System.out.print(letter.getLetter());
    }

    System.out.println();
  }
}

package servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Game;
import models.Letter;
import service.HangmanService;
import service.HangmanServiceImpl;

@WebServlet("/makeTry")
public class MakeTryServlet extends HttpServlet {

  private HangmanService service = new HangmanServiceImpl();

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    getServletContext().getRequestDispatcher("/index.jsp").forward(req, resp);
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    String input = req.getParameter("letter");
    String gameId = (String) req.getSession().getAttribute("gameId");

    if (isValidInput(input)) {

      Letter letter = new Letter(input.charAt(0), false);
      Game game = service.makeGuess(gameId, letter);

      if (isWon(game) || isLost(game)) {

        service.deleteGame(gameId);
        setResp(resp, isWon(game));
        return;
      }
    }

    getServletContext().getRequestDispatcher("/WEB-INF/jsp/game.jsp").forward(req, resp);
  }

  private boolean isValidInput(String letter) {

    if (letter == null || letter.length() != 1)
      return false;

    char charLetter = letter.charAt(0);

    return (charLetter >= 'a' && charLetter <= 'z') || (charLetter >= 'A' && charLetter <= 'Z');
  }

  private boolean isWon(Game game) {

    for (Letter letter : game.getWord()) {
      if (!letter.isCorrect()) {
        return false;
      }
    }

    return true;
  }

  private boolean isLost(Game game) {
    return game.getTriesMade() >= 6;
  }

  private void setResp(HttpServletResponse resp, boolean isWin) throws IOException {

    String status = (isWin) ? "WIN" : "LOSE";

    String headTag = "<head><title>" + status
        + "</title><link href=\"css/style.css\" rel=\"stylesheet\"></head>";

    String goBackButton = "<a href='/hangman'>Go back</a>";

    String startNewGameButton =
        "<a class='submitButton' style='text-decoration: none' href='startNewGame'>Start new game</a>";

    String bodyTag = "<body class='result-page'><h1>You " + status + "!</h1>" + goBackButton
        + "<br>" + startNewGameButton + "</body>";

    resp.getWriter().write("<html>" + headTag + bodyTag + "</html>");
    resp.flushBuffer();
  }
}

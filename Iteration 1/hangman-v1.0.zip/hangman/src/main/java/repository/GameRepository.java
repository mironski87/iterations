package repository;

import java.util.ArrayList;
import java.util.List;
import models.Game;

public class GameRepository {

  private static List<Game> games = new ArrayList<Game>();

  private GameRepository() {}

  public static List<Game> getAllGames() {
    return games;
  }

  public static Game getGameById(String gameId) {

    for (Game game : games) {
      if (game.getGameId().equals(gameId)) {
        return game;
      }
    }

    return null;
  }

  public static boolean addGame(Game game) {

    if (games.contains(game)) {
      return false;
    }

    return games.add(game);
  }

  public static boolean updateGame(Game game) {

    for (Game gameItem : games) {
      if (gameItem.getGameId().equals(game.getGameId())) {

        games.remove(gameItem);
        games.add(game);

        return true;
      }
    }

    return false;
  }

  public static boolean deleteGame(Game game) {
    return games.remove(game);
  }
}

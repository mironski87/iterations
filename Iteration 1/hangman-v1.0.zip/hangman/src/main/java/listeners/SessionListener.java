package listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import service.HangmanServiceImpl;

@WebListener("/")
public class SessionListener implements HttpSessionListener {

  private HangmanServiceImpl service = new HangmanServiceImpl();

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    se.getSession().setAttribute("gameId", se.getSession().getId());
  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    service.deleteGame(se.getSession().getId());
  }
}

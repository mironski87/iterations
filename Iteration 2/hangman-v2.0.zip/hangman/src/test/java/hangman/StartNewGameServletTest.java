package hangman;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.Game;
import models.Letter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import repository.GameRepository;
import service.HangmanService;
import service.HangmanServiceImpl;
import servlets.StartNewGameServlet;

class StartNewGameServletTest {

  private final String SESSION_ID = "123456";

  private HttpServletRequest request;
  private HttpServletResponse response;
  private HttpSession session;

  private ServletConfig sc;
  private ServletContext context;


  private StartNewGameServlet servlet;

  private GameRepository gameRepository;
  private HangmanService gameService;

  private Game game;
  private RequestDispatcher dispatcher;

  @BeforeEach
  void startUp() {

    // Create mock Request, Repository and Session objects
    request = Mockito.mock(HttpServletRequest.class);
    response = Mockito.mock(HttpServletResponse.class);
    session = Mockito.mock(HttpSession.class);

    sc = Mockito.mock(ServletConfig.class);
    context = Mockito.mock(ServletContext.class);

    // Create mock Service and Repository objects
    gameRepository = Mockito.mock(GameRepository.class);
    gameService = new HangmanServiceImpl(gameRepository);
    gameService = Mockito.spy(gameService);

    servlet = new StartNewGameServlet() {
      @Override
      public ServletContext getServletContext() {
        return context;
      }
    };

    // Set the helper objects
    List<Letter> word = new ArrayList<>();
    word.add(new Letter('a', false));
    game = new Game(SESSION_ID, word);

    dispatcher = Mockito.mock(RequestDispatcher.class);
  }

  @Test
  void testStartNewGameServlet() throws IOException, ServletException {

    // Set up the request object to include a session attribute
    Mockito.when(request.getSession()).thenReturn(session);

    // Set up the session object to include a sessionId attribute
    Mockito.when(session.getId()).thenReturn(SESSION_ID);

    // Set up the Service and Repository objects to return appropriate values
    doReturn(game).when(gameService).startNewGame(SESSION_ID);
    Mockito.when(gameRepository.addGame(game)).thenReturn(true);

    // Set up the ServletConfig object to return appropriate value
    doReturn(dispatcher).when(context).getRequestDispatcher(anyString());

    // Inject the mock Service and ServletConfig dependency
    servlet.init(sc);
    servlet.setService(gameService);

    // Call the Servlet's doGet() method with the mock request and response objects
    servlet.doGet(request, response);

    // Verify that the Service and Repository methods were called with the expected sessionId
    Mockito.verify(gameService).startNewGame(SESSION_ID);

    // Verify that the Servlet forwarded the request to the correct JSP page
    Mockito.verify(dispatcher).forward(request, response);
  }
}

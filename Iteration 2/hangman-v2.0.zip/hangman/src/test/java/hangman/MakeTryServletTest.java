package hangman;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import models.Game;
import models.Letter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import repository.GameRepository;
import repository.GameRepositoryImpl;
import service.HangmanService;
import service.HangmanServiceImpl;
import servlets.MakeTryServlet;

class MakeTryServletTest {

  private final String SESSION_ID = "123456";

  private HttpServletRequest request;
  private HttpServletResponse response;
  private HttpSession session;

  private ServletConfig sc;
  private ServletContext context;


  private MakeTryServlet servlet;

  private GameRepository gameRepository;
  private HangmanService gameService;

  private Game game;
  private RequestDispatcher dispatcher;

  @BeforeEach
  void startUp() {

    // Create mock Request, Repository and Session objects
    request = Mockito.mock(HttpServletRequest.class);
    response = Mockito.mock(HttpServletResponse.class);
    session = Mockito.mock(HttpSession.class);

    sc = Mockito.mock(ServletConfig.class);
    context = Mockito.mock(ServletContext.class);

    // Create mock Service and Repository objects
    gameRepository = new GameRepositoryImpl();
    gameService = new HangmanServiceImpl(gameRepository);
    gameService = Mockito.spy(gameService);

    servlet = new MakeTryServlet() {
      @Override
      public ServletContext getServletContext() {
        return context;
      }
    };

    dispatcher = Mockito.mock(RequestDispatcher.class);
  }

  @Test
  void testMakeTryServlet() throws ServletException, IOException {

    Mockito.when(request.getSession()).thenReturn(session);
    Mockito.when(session.getAttribute(anyString())).thenReturn(SESSION_ID);

    Mockito.when(request.getParameter(anyString())).thenReturn("p");

    game = gameService.startNewGame(SESSION_ID);
    setWordToTest();

    doReturn(dispatcher).when(context).getRequestDispatcher(anyString());

    servlet.init(sc);
    servlet.setService(gameService);

    servlet.doPost(request, response);

    Mockito.verify(gameService).makeGuess(anyString(), any());
    Mockito.verify(dispatcher).forward(request, response);
  }

  @Test
  void testMakeTryServletInvalidInput() throws ServletException, IOException {

    Mockito.when(request.getSession()).thenReturn(session);
    Mockito.when(session.getAttribute(anyString())).thenReturn(SESSION_ID);

    Mockito.when(request.getParameter(anyString())).thenReturn("1");

    game = gameService.startNewGame(SESSION_ID);

    doReturn(dispatcher).when(context).getRequestDispatcher(anyString());

    servlet.init(sc);
    servlet.setService(gameService);

    servlet.doPost(request, response);

    Mockito.verify(gameService, never()).makeGuess(anyString(), any());
    Mockito.verify(dispatcher).forward(request, response);
  }

  @Test
  void testMakeTryServletWon() throws ServletException, IOException {

    Mockito.when(request.getSession()).thenReturn(session);
    Mockito.when(session.getAttribute(anyString())).thenReturn(SESSION_ID);
    Mockito.when(request.getParameter(anyString())).thenReturn("e");

    StringWriter stringWriter = new StringWriter();
    PrintWriter writer = new PrintWriter(stringWriter);
    when(response.getWriter()).thenReturn(writer);

    game = gameService.startNewGame(SESSION_ID);
    setWordToTest();

    for (Letter letter : game.getWord()) {

      if (letter.getLetter() == 'e') {
        continue;
      }

      letter.setCorrect(true);
    }

    doReturn(dispatcher).when(context).getRequestDispatcher(anyString());

    servlet.init(sc);
    servlet.setService(gameService);

    servlet.doPost(request, response);

    Mockito.verify(gameService).makeGuess(anyString(), any());
    assertThat(game.isWon()).isTrue();
  }

  private void setWordToTest() {

    List<Letter> newWord = new ArrayList<>();

    newWord.add(new Letter('t', false));
    newWord.add(new Letter('e', false));
    newWord.add(new Letter('s', false));
    newWord.add(new Letter('t', false));

    this.game.setWord(newWord);
  }
}

package utility;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import models.Letter;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

public class RandomWordUtil {

  private static String STARTING_URL =
      "https://www.oxfordlearnersdictionaries.com/wordlist/american_english/oxford3000/";

  // Reactor pickedWord (String) to List<Letter>
  public static List<Letter> generate() {

    char[] wordArray = pickWord().toCharArray();
    List<Letter> wordIntoLetters = new ArrayList<Letter>();

    for (int i = 0; i < wordArray.length; i++) {
      wordIntoLetters.add(new Letter(wordArray[i], false));
    }

    return wordIntoLetters;
  }

  // checks if word is valid length
  private static String pickWord() {

    Random random = new Random();

    String word = "";

    try {
      word = getRandomWord(random);
    } catch (IOException e) {
      e.printStackTrace();
    }

    if (word.length() <= 5) {
      word = pickWord();
    }

    for (Character letter : word.toCharArray()) {
      if (letter < 'a' || letter > 'z') {
        word = pickWord();
      }
    }

    return word;
  }

  // provides random WORD
  private static String getRandomWord(Random random) throws IOException {

    // connect the link PAGE_NUMBER provided
    // get the "entrylist1" container storing all the words
    // words values are under <a> tag
    // @param: words - stores them
    Elements words = Jsoup.connect(getRandomPageNumberUrl(random)).get()
        .getElementById("entrylist1").getElementsByTag("a");

    // get RANDOM <a> of the available and return the text value
    return words.get(random.nextInt(words.size())).text();
  }

  // provides random PAGE_NUMBER page
  private static String getRandomPageNumberUrl(Random random) throws IOException {

    // connect the link LETTER_PAGE provided
    // get the "paging" container storing all the pages links
    // store them @param: pages
    Elements pages = Jsoup.connect(getRandomLetterPageUrl(random)).get().getElementById("paging")
        .getElementsByTag("a");

    // get RANDOM link of the available and return the value in its HREF attribute
    return pages.get(random.nextInt(pages.size())).attr("href");
  }

  // provides random LETTER page
  private static String getRandomLetterPageUrl(Random random) throws IOException {

    // connects the url, we get entries-selector element which contains all the LETTERS links
    // and store them in entriesElements
    Elements entriesElement =
        Jsoup.connect(STARTING_URL).get().getElementById("entries-selector").getElementsByTag("a");

    // get RANDOM link of the available and return the value in its HREF attribute
    return entriesElement.get(random.nextInt(entriesElement.size())).attr("href");
  }
}

package servlets;

import configuration.ApplicationConfiguration;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Game;
import models.Letter;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import service.HangmanService;

@WebServlet("/makeTry")
public class MakeTryServlet extends HttpServlet {

  private HangmanService hangmanService;

  @Override
  public void init() {

    AnnotationConfigApplicationContext context =
        new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
    this.hangmanService = context.getBean(HangmanService.class);
    context.close();
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {
    getServletContext().getRequestDispatcher("/index.jsp").forward(req, resp);
  }

  @Override
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    String input = req.getParameter("letter");
    String gameId = (String) req.getSession().getAttribute("gameId");

    if (isValidInput(input)) {

      Letter letter = new Letter(input.charAt(0), false);
      Game game = hangmanService.makeGuess(gameId, letter);

      if (game.isWon() || game.isLost()) {

        hangmanService.deleteGame(gameId);
        setResp(resp, game.isWon());
        return;
      }

      getServletContext().setAttribute("game", game);
    }

    getServletContext().getRequestDispatcher("/WEB-INF/jsp/game.jsp").forward(req, resp);
  }

  public void setService(HangmanService service) {
    this.hangmanService = service;
  }

  private boolean isValidInput(String letter) {

    if (letter == null || letter.length() != 1)
      return false;

    char charLetter = letter.charAt(0);

    return (charLetter >= 'a' && charLetter <= 'z') || (charLetter >= 'A' && charLetter <= 'Z');
  }

  private void setResp(HttpServletResponse resp, boolean isWin) throws IOException {

    String status = (isWin) ? "WIN" : "LOSE";

    String headTag = "<head><title>" + status
        + "</title><link href=\"css/style.css\" rel=\"stylesheet\"></head>";

    String goBackButton = "<a href='/hangman'>Go back</a>";

    String startNewGameButton =
        "<a class='submitButton' style='text-decoration: none' href='startNewGame'>Start new game</a>";

    String bodyTag = "<body class='result-page'><h1>You " + status + "!</h1>" + goBackButton
        + "<br>" + startNewGameButton + "</body>";

    resp.getWriter().write("<html>" + headTag + bodyTag + "</html>");
    resp.flushBuffer();
  }
}

package servlets;

import configuration.ApplicationConfiguration;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Game;
import models.Letter;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import service.HangmanService;

@WebServlet("/startNewGame")
public class StartNewGameServlet extends HttpServlet {

  private HangmanService hangmanService;

  @Override
  public void init() {

    AnnotationConfigApplicationContext context =
        new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
    this.hangmanService = context.getBean(HangmanService.class);
    context.close();
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException, IOException {

    Game game = hangmanService.startNewGame(req.getSession().getId());
    wordPrintInConsole(game);

    getServletContext().setAttribute("game", game);
    getServletContext().getRequestDispatcher("/WEB-INF/jsp/game.jsp").forward(req, resp);
  }

  public void setService(HangmanService service) {
    this.hangmanService = service;
  }

  private void wordPrintInConsole(Game game) {

    for (Letter letter : game.getWord()) {
      System.out.print(letter.getLetter());
    }

    System.out.println();
  }
}

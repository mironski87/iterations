package service;

import models.Game;
import models.Letter;
import repository.GameRepository;
import utility.RandomWordUtil;

public class HangmanServiceImpl implements HangmanService {

  private GameRepository gameRepository;

  public HangmanServiceImpl(GameRepository gameRepository) {
    this.gameRepository = gameRepository;
  }

  @Override
  public Game startNewGame(String sessionId) {

    if (gameRepository.getGameById(sessionId) != null) {
      deleteGame(sessionId);
    }

    Game game = new Game(sessionId, RandomWordUtil.generate());
    gameRepository.addGame(game);

    return game;
  }

  @Override
  public Game getGame(String gameId) {
    return gameRepository.getGameById(gameId);
  }

  @Override
  public Game makeGuess(String gameId, Letter letter) {

    Game game = gameRepository.getGameById(gameId);

    if (doGameTriesContainsThisLetter(game, letter)) {
      return game;
    }

    boolean doWordContainsTheLetter = doWordContains(game, letter);

    letter.setCorrect(doWordContainsTheLetter);
    game.getAlphabetsPicked().add(letter);

    if (!doWordContainsTheLetter) {
      game.addWrongAttemptCount();
    }

    gameRepository.updateGame(game);
    return game;
  }

  @Override
  public void deleteGame(String gameId) {

    Game game = gameRepository.getGameById(gameId);
    gameRepository.deleteGame(game);
  }

  // checks if this word was already given as pick
  public boolean doGameTriesContainsThisLetter(Game game, Letter letter) {

    for (Letter letterItem : game.getAlphabetsPicked()) {
      if (letterItem.getLetter() == letter.getLetter()) {
        return true;
      }
    }

    return false;
  }

  // checks if the given letter is inside the game's word
  // if so: changes word's letter to true
  public boolean doWordContains(Game game, Letter letter) {

    boolean doContains = false;

    for (Letter item : game.getWord()) {
      if (item.getLetter() == letter.getLetter()) {

        item.setCorrect(true);
        doContains = true;
      }
    }

    return doContains;
  }
}

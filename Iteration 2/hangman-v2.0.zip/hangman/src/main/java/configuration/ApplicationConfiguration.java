package configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import repository.GameRepository;
import repository.GameRepositoryImpl;
import service.HangmanService;
import service.HangmanServiceImpl;

@Configuration
public class ApplicationConfiguration {

  @Bean
  public GameRepository gameRepository() {
    return new GameRepositoryImpl();
  }

  @Bean
  public HangmanService hangmanService() {
    return new HangmanServiceImpl(gameRepository());
  }
}

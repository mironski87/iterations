package listeners;

import configuration.ApplicationConfiguration;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import service.HangmanService;

@WebListener("/")
public class SessionListener implements HttpSessionListener {

  @Autowired
  private HangmanService hangmanService;

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    se.getSession().setAttribute("gameId", se.getSession().getId());
  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {

    if (this.hangmanService == null) {
      AnnotationConfigApplicationContext context =
          new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
      this.hangmanService = context.getBean(HangmanService.class);
      context.close();
    }

    hangmanService.deleteGame(se.getSession().getId());
  }
}

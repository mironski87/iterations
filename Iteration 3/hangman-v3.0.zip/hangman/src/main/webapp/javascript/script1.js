 function changeLanguage() {
	 
  const bgRadio = document.getElementById("bulgarian");
  const enRadio = document.getElementById("english");
  
  const heading = document.getElementById("heading");
  const button = document.getElementById("button");
  const link = document.getElementById("link");

  if (bgRadio.checked) {
    heading.innerText = "Добре дошли в Бесеница";
    button.value = "Нова игра"
    link.innerText = "Игра за двама"
    
  } else if (enRadio.checked) {
    heading.innerText = "Welcome to Hangman";
    button.value = "Start new game"
    link.innerText = "Double player game"
  }
}
package models.validate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class InputValidator {

  @NotNull(message = "This field is required.")
  @Pattern(regexp = "^[\\u0430-\\u044f]$|^[\\p{IsLatin}]$",
      message = "Field should contain single, lowercase letter.")
  private String input;

  public String getInput() {
    return this.input;
  }

  public void setInput(String input) {
    this.input = input;
  }
}

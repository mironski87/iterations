package models.validate;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class WordInputValidator {

  @Size(min = 5, max = 20, message = "Atleast 5 chars and max 20 characters")
  @Pattern(regexp = "^[\\u0430-\\u044f]+$|^[a-z]+$", message = "Invalid word")
  private String word;

  public String getWord() {
    return word;
  }

  public void setWord(String word) {
    this.word = word;
  }
}

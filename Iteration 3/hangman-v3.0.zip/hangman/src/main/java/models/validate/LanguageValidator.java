package models.validate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class LanguageValidator {

  @NotNull(message = "This field is required.")
  @Pattern(regexp = "^english$|^bulgarian$", message = "Don't change radio's values")
  private String language;

  public String getLanguage() {
    return this.language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }
}

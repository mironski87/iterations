package service;

import models.Game;
import models.Letter;

public interface HangmanService {

  Game startNewGame(String sessionId, String word);

  Game startNewGame(String sessionId, boolean isEnglish);

  Game getGame(String gameId);

  Game makeGuess(String gameId, Letter letter);

  void deleteGame(String gameId);
}

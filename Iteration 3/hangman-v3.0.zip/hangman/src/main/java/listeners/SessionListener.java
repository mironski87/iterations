package listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import org.springframework.beans.factory.annotation.Autowired;
import service.HangmanService;

@WebListener("/")
public class SessionListener implements HttpSessionListener {

  private HangmanService service;

  @Autowired
  public void setService(HangmanService service) {
    this.service = service;
  }

  @Override
  public void sessionCreated(HttpSessionEvent se) {
    se.getSession().setAttribute("gameId", se.getSession().getId());
  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    service.deleteGame(se.getSession().getId());
  }
}

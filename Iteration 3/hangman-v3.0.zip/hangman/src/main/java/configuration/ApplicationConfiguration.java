package configuration;

import controllers.ApplicationController;
import controllers.DoublePlayerController;
import controllers.ExceptionHandlerController;
import controllers.SinglePlayerController;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import repository.GameRepository;
import repository.GameRepositoryImpl;
import service.HangmanService;
import service.HangmanServiceImpl;

@Configuration
@EnableWebMvc
public class ApplicationConfiguration {

  @Bean
  public GameRepository gameRepository() {
    return new GameRepositoryImpl();
  }

  @Bean
  public HangmanService hangmanService() {
    return new HangmanServiceImpl(gameRepository());
  }

  @Bean
  public ApplicationController applicationController() {
    return new ApplicationController();
  }

  @Bean
  public SinglePlayerController singlePlayerController() {
    return new SinglePlayerController(hangmanService());
  }

  @Bean
  public DoublePlayerController doublePlayerController() {
    return new DoublePlayerController(hangmanService());
  }

  @Bean
  public ExceptionHandlerController exceptionHandlerController() {
    return new ExceptionHandlerController();
  }

  @Bean
  public MessageSource messageSource() {
    ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
    messageSource.setBasename("messages");
    messageSource.setDefaultEncoding("UTF-8");
    return messageSource;
  }

  @Bean
  public LocalValidatorFactoryBean localValidatorFactoryBean() {

    LocalValidatorFactoryBean validatorFactoryBean = new LocalValidatorFactoryBean();
    validatorFactoryBean.setValidationMessageSource(messageSource());
    return validatorFactoryBean;
  }

  @Bean
  public InternalResourceViewResolver viewResolver() {

    InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
    viewResolver.setPrefix("/WEB-INF/jsp/");
    viewResolver.setSuffix(".jsp");
    return viewResolver;
  }
}

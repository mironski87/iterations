package controllers;

import models.validate.LanguageValidator;
import models.validate.WordInputValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationController {

  @GetMapping("/")
  public String getIndex(Model model) {

    model.addAttribute("language", new LanguageValidator());
    return "index";
  }

  @GetMapping("/pickWord")
  public String getPickWordPage(Model model) {

    model.addAttribute("wordInputValidator", new WordInputValidator());
    return "pick-word";
  }
}

package controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import models.Game;
import models.Letter;
import models.validate.InputValidator;
import models.validate.LanguageValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import service.HangmanService;
import utility.LatinCyrillicInputValidator;
import utility.PrintWordUtil;

@Controller
public class SinglePlayerController {

  private HangmanService service;

  public SinglePlayerController(HangmanService service) {
    this.service = service;
  }

  @PostMapping("/startNewGame")
  public String startNewGame(
      @Valid @ModelAttribute("languageValid") LanguageValidator languageValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    session.setAttribute("isEnglish", "english".equals(languageValidator.getLanguage()));

    if (bindingResult.hasErrors()) {
      model.addAttribute("language", new LanguageValidator());
      model.addAttribute("errors", bindingResult);
      return "index";
    }

    Game game =
        service.startNewGame(session.getId(), "english".equals(languageValidator.getLanguage()));
    PrintWordUtil.print(game);

    setModel(model, game);
    return "game";
  }

  @PostMapping("/makeTry")
  public String makeTry(@Valid @ModelAttribute("inputValidator") InputValidator inputValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    Game game = service.getGame(session.getId());

    if (bindingResult.hasErrors()) {
      setModel(model, game);
      model.addAttribute("errors", bindingResult);
      return "game";
    }

    Letter letter = new Letter(inputValidator.getInput().charAt(0), false);
    boolean isEnglish = (boolean) session.getAttribute("isEnglish");

    if (LatinCyrillicInputValidator.validate(isEnglish, letter)) {

      game = service.makeGuess(game.getGameId(), letter);

      if (game.isWon() || game.isLost()) {
        service.deleteGame(game.getGameId());
        model.addAttribute("isWon", game.isWon());
        return "result";
      }
    }

    setModel(model, game);
    return "game";
  }

  private void setModel(Model model, Game game) {

    model.addAttribute("game", game);
    model.addAttribute("inputValidator", new InputValidator());
    model.addAttribute("language", new LanguageValidator());
  }
}

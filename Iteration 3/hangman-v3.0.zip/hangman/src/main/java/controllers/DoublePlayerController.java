package controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import models.Game;
import models.validate.WordInputValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import service.HangmanService;
import utility.PrintWordUtil;

@Controller
public class DoublePlayerController {

  private HangmanService service;

  public DoublePlayerController(HangmanService service) {
    this.service = service;
  }

  @PostMapping("/pickWord")
  public String getPickWord(
      @Valid @ModelAttribute("wordInputValidator") WordInputValidator wordValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    if (bindingResult.hasErrors()) {
      model.addAttribute("errors", bindingResult);
      return "pick-word";
    }

    boolean isCyrillic = isCyrillic(wordValidator);
    boolean isLatin = isLatin(wordValidator);

    if (isCyrillic || isLatin) {

      session.setAttribute("isEnglish", isLatin(wordValidator));
      Game game = service.startNewGame(session.getId(), wordValidator.getWord());
      PrintWordUtil.print(game);

      model.addAttribute("game", game);
      return "game";
    }

    model.addAttribute("message", "Just error");
    return "error";
  }

  private boolean isCyrillic(WordInputValidator wordValidator) {

    for (Character letter : wordValidator.getWord().toCharArray()) {
      if (letter < 'а' || letter > 'я') {
        return false;
      }
    }
    return true;
  }

  private boolean isLatin(WordInputValidator wordValidator) {

    for (Character letter : wordValidator.getWord().toCharArray()) {
      if (letter < 'a' || letter > 'z') {
        return false;
      }
    }
    return true;
  }
}

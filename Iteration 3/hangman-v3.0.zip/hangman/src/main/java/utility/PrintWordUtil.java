package utility;

import models.Game;
import models.Letter;

public class PrintWordUtil {

  private PrintWordUtil() {

  }

  public static void print(Game game) {

    for (Letter letter : game.getWord()) {
      System.out.print(letter.getLetter());
    }

    System.out.println();
  }
}

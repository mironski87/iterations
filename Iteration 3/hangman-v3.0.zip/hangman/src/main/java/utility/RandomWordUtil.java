package utility;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import models.Letter;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;

public class RandomWordUtil {

  private static final String STARTING_ENGLISH_URL =
      "https://www.oxfordlearnersdictionaries.com/wordlist/american_english/oxford3000/";

  private static String startingBulgarianUrl = "https://slovored.com";

  // Reactor pickedWord (String) to List<Letter>
  public static List<Letter> generate(boolean isEnglish) {

    char[] wordArray = pickWord(isEnglish).toCharArray();
    List<Letter> wordIntoLetters = new ArrayList<Letter>();

    for (int i = 0; i < wordArray.length; i++) {
      wordIntoLetters.add(new Letter(wordArray[i], false));
    }

    return wordIntoLetters;
  }

  // checks if word is valid length
  private static String pickWord(boolean isEnglish) {

    Random random = new Random();

    String word = "";

    try {
      word = (isEnglish) ? getRandomEnglishWord(random) : getRandomBulgarianWord(random);

    } catch (IOException e) {
      e.printStackTrace();
    }

    if (word.length() <= 5) {
      word = pickWord(isEnglish);
    }

    for (Character letter : word.toCharArray()) {
      if ((letter < 'a' || letter > 'z') && (letter < 'а' || letter > 'я')) {
        word = pickWord(isEnglish);
      }
    }

    return word;
  }

  // ======================= ENGLISH WORD GENERATE METHODS ==========================

  // provides random WORD
  private static String getRandomEnglishWord(Random random) throws IOException {

    // connect the link PAGE_NUMBER provided
    // get the "entrylist1" container storing all the words
    // words values are under <a> tag
    // @param: words - stores them
    Elements words = Jsoup.connect(getRandomPageNumberUrl(random)).get()
        .getElementById("entrylist1").getElementsByTag("a");

    // get RANDOM <a> of the available and return the text value
    return words.get(random.nextInt(words.size())).text();
  }

  // provides random PAGE_NUMBER page
  private static String getRandomPageNumberUrl(Random random) throws IOException {

    // connect the link LETTER_PAGE provided
    // get the "paging" container storing all the pages links
    // store them @param: pages
    Elements pages = Jsoup.connect(getRandomLetterPageUrl(random)).get().getElementById("paging")
        .getElementsByTag("a");

    // get RANDOM link of the available and return the value in its HREF attribute
    return pages.get(random.nextInt(pages.size())).attr("href");
  }

  // provides random LETTER page
  private static String getRandomLetterPageUrl(Random random) throws IOException {

    // connects the url, we get entries-selector element which contains all the LETTERS links
    // and store them in entriesElements
    Elements entriesElement = Jsoup.connect(STARTING_ENGLISH_URL).get()
        .getElementById("entries-selector").getElementsByTag("a");

    // get RANDOM link of the available and return the value in its HREF attribute
    return entriesElement.get(random.nextInt(entriesElement.size())).attr("href");
  }

  // ======================== BULGARIAN WORD GENERATE METHODS ================================

  private static String getRandomBulgarianWord(Random random) throws IOException {

    Elements words = Jsoup.connect(getRandomSecondLetter(random)).get().getElementsByClass("words")
        .get(0).getElementsByTag("a");

    return words.get(random.nextInt(words.size())).text();
  }

  private static String getRandomSecondLetter(Random random) throws IOException {

    String url = getRandomFirstLetter(random);

    Elements letters =
        Jsoup.connect(url).get().getElementsByClass("links").get(0).getElementsByTag("a");

    return startingBulgarianUrl + letters.get(random.nextInt(letters.size())).attr("href");
  }

  private static String getRandomFirstLetter(Random random) throws IOException {

    Elements letters = Jsoup.connect(startingBulgarianUrl + "/sitemap/english").get()
        .getElementsByClass("links").get(1).getElementsByTag("a");

    return startingBulgarianUrl + letters.get(random.nextInt(letters.size())).attr("href");
  }
}

package repository;

import java.util.ArrayList;
import java.util.List;
import models.Game;

public interface GameRepository {

  public static List<Game> games = new ArrayList<Game>();

  Game getGameById(String gameId);

  boolean addGame(Game game);

  boolean updateGame(Game game);

  boolean deleteGame(Game game);
}

package unit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;
import configuration.ApplicationConfiguration;
import models.validate.WordInputValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

public class DoublePlayerControllerTest {

  private ApplicationConfiguration config = new ApplicationConfiguration();
  private MockMvc mockMvc;

  @BeforeEach
  void setup() {
    mockMvc = standaloneSetup(config.doublePlayerController()).build();
  }

  @Test
  void pickWordTest() throws Exception {

    WordInputValidator wordValidator = new WordInputValidator();
    wordValidator.setWord("testword");

    mockMvc.perform(post("/pickWord").flashAttr("wordInputValidator", wordValidator))
        .andExpect(status().isOk()).andExpect(view().name("game"));
  }
}

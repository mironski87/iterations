package unit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import java.util.ArrayList;
import java.util.List;
import models.Game;
import models.Letter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import repository.GameRepositoryImpl;
import service.HangmanServiceImpl;
import utility.RandomWordUtil;

@ExtendWith(MockitoExtension.class)
class HangmanServiceImplTest {

  @Mock
  GameRepositoryImpl gameRepository;
  HangmanServiceImpl hangmanService;

  @BeforeEach
  void setUp() {
    hangmanService = new HangmanServiceImpl(gameRepository);
    hangmanService = Mockito.spy(hangmanService);
  }

  void testRandomWordGenerate() {
    assertThat(RandomWordUtil.generate(true)).hasSizeGreaterThanOrEqualTo(5);
  }

  @Test
  void testDoGameTriesContainsThisLetter() {

    List<Letter> word = new ArrayList<>();
    word.add(new Letter('t', true));
    word.add(new Letter('e', false));
    word.add(new Letter('s', false));
    word.add(new Letter('t', true));

    Letter checkLetter = new Letter('t', true);

    Game game = new Game("1", word);
    game.getAlphabetsPicked().add(checkLetter);

    assertTrue(hangmanService.doGameTriesContainsThisLetter(game, new Letter('t', false)));

    assertFalse(hangmanService.doGameTriesContainsThisLetter(game, new Letter('e', false)));
    assertFalse(hangmanService.doGameTriesContainsThisLetter(game, new Letter('j', false)));
  }

  @Test
  void testDoWordContains() {

    List<Letter> word = new ArrayList<>();
    word.add(new Letter('t', false));
    word.add(new Letter('e', false));
    word.add(new Letter('s', false));
    word.add(new Letter('t', false));

    Game game = new Game("1", word);

    Letter checkLetter = new Letter('t', false);
    assertTrue(hangmanService.doWordContains(game, checkLetter));
    assertTrue(game.getWord().get(0).isCorrect());
    assertTrue(game.getWord().get(3).isCorrect());

    checkLetter = new Letter('e', false);
    assertTrue(hangmanService.doWordContains(game, checkLetter));
    assertTrue(game.getWord().get(1).isCorrect());

    checkLetter = new Letter('s', false);
    assertTrue(hangmanService.doWordContains(game, checkLetter));
    assertTrue(game.getWord().get(2).isCorrect());

    checkLetter = new Letter('j', false);
    assertFalse(hangmanService.doWordContains(game, checkLetter));
  }

  @Test
  void testStartNewGame() {

    Game game = hangmanService.startNewGame("123456", "english");

    assertThat(game).isNotNull();
    assertThat(game.getGameId()).isEqualTo("123456");
    assertThat(game.getWord()).isNotNull();
    assertThat(game.getAlphabetsPicked()).isEmpty();
    assertThat(game.getWrongAttemptsCounter()).isZero();
    verify(gameRepository).addGame(any());
  }

  @Test
  void testMakeTry() {

    List<Letter> word = new ArrayList<>();
    word.add(new Letter('t', false));
    word.add(new Letter('e', false));
    word.add(new Letter('s', false));
    word.add(new Letter('t', false));

    Game game = new Game("1", word);
    doReturn(game).when(gameRepository).getGameById("1");

    Game result = hangmanService.makeGuess("1", new Letter('t', false));

    assertThat(result.getWord()).isEqualTo(word);
    assertThat(result.getGameId()).isEqualTo("1");
    assertThat(result.getWrongAttemptsCounter()).isZero();

    assertThat(result.getAlphabetsPicked()).hasSize(1);
    assertThat(result.getAlphabetsPicked().get(0).isCorrect()).isTrue();

    assertThat(result.getWord().get(0).isCorrect()).isTrue();
    assertThat(result.getWord().get(1).isCorrect()).isFalse();
    assertThat(result.getWord().get(2).isCorrect()).isFalse();
    assertThat(result.getWord().get(3).isCorrect()).isTrue();

    result = hangmanService.makeGuess("1", new Letter('z', false));

    assertThat(result.getWord()).isEqualTo(word);
    assertThat(result.getGameId()).isEqualTo("1");
    assertThat(result.getWrongAttemptsCounter()).isEqualTo(1);

    assertThat(result.getAlphabetsPicked()).hasSize(2);
    assertThat(result.getAlphabetsPicked().get(1).isCorrect()).isFalse();

    assertThat(result.getWord().get(0).isCorrect()).isTrue();
    assertThat(result.getWord().get(1).isCorrect()).isFalse();
    assertThat(result.getWord().get(2).isCorrect()).isFalse();
    assertThat(result.getWord().get(3).isCorrect()).isTrue();
  }

  @Test
  void deleteGame() {

    Game game = hangmanService.startNewGame("1", "english");
    assertThat(game).isNotNull();

    hangmanService.deleteGame(game.getGameId());
    assertThat(hangmanService.getGame(game.getGameId())).isNull();
  }
}

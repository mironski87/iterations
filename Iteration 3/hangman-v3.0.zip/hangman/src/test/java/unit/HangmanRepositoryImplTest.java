package unit;

import static org.assertj.core.api.Assertions.assertThat;
import models.Game;
import org.junit.jupiter.api.Test;
import repository.GameRepository;
import repository.GameRepositoryImpl;

class HangmanRepositoryImplTest {

  GameRepository repo = new GameRepositoryImpl();
  Game game = new Game("1", null);

  @Test
  void testAddGame() {

    repo.addGame(game);
    assertThat(GameRepository.games.get(0).getGameId()).isEqualTo(game.getGameId());
  }

  @Test
  void testGetGame() {

    assertThat(repo.getGameById("1").getGameId()).isEqualTo(game.getGameId());
  }

  @Test
  void testUpdateGame() {

    game.addWrongAttemptCount();
    repo.updateGame(game);

    assertThat(repo.getGameById("1").getWrongAttemptsCounter()).isEqualTo(game.getWrongAttemptsCounter());
  }

  @Test
  void testDeleteGame() {

    repo.deleteGame(game);
    assertThat(repo.getGameById("1")).isNull();
  }
}

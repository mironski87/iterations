package unit;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;
import configuration.ApplicationConfiguration;
import controllers.SinglePlayerController;
import java.util.ArrayList;
import java.util.List;
import models.Game;
import models.Letter;
import models.validate.InputValidator;
import models.validate.LanguageValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import service.HangmanService;
import service.HangmanServiceImpl;

class SinglePlayerControllerTest {

  private ApplicationConfiguration config = new ApplicationConfiguration();
  private MockMvc mockMvc;

  @BeforeEach
  void setup() {
    mockMvc = standaloneSetup(config.singlePlayerController()).build();
  }

  @Test
  void startNewGameTest() throws Exception {

    LanguageValidator langValidator = new LanguageValidator();
    langValidator.setLanguage("english");

    mockMvc.perform(post("/startNewGame").flashAttr("languageValid", langValidator))
        .andExpect(status().isOk()).andExpect(view().name("game"));
  }

  @Test
  void makeTryTest() throws Exception {

    HangmanService service = mock(HangmanServiceImpl.class);
    mockMvc = standaloneSetup(new SinglePlayerController(service)).build();

    List<Letter> word = new ArrayList<>();
    word.add(new Letter('t', false));
    word.add(new Letter('e', false));
    word.add(new Letter('s', false));
    word.add(new Letter('t', false));

    Game game = new Game("123", word);

    when(service.getGame(anyString())).thenReturn(game);
    when(service.makeGuess(anyString(), any())).thenReturn(game);

    InputValidator inputValidator = new InputValidator();
    inputValidator.setInput("a");

    mockMvc
        .perform(post("/makeTry").flashAttr("inputValidator", inputValidator)
            .sessionAttr("isEnglish", true))
        .andExpect(status().isOk()).andExpect(view().name("game"));
  }
}

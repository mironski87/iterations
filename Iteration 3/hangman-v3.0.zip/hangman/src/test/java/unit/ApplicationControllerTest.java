package unit;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;
import configuration.ApplicationConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;

class ApplicationControllerTest {

  private MockMvc mockMvc;
  private ApplicationConfiguration config = new ApplicationConfiguration();

  @BeforeEach
  void setup() {
    mockMvc = standaloneSetup(config.applicationController()).build();
  }

  @Test
  void testGetIndex() throws Exception {
    mockMvc.perform(get("/")).andExpect(status().isOk()).andExpect(view().name("index"));
  }

  @Test
  void testGetPickWord() throws Exception {
    mockMvc.perform(get("/pickWord")).andExpect(status().isOk())
        .andExpect(view().name("pick-word"));
  }
}

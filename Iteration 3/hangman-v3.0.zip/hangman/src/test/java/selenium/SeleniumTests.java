package selenium;

import static org.assertj.core.api.Assertions.assertThat;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

class SeleniumTests {

  WebDriver driver;

  @BeforeAll
  static void setupAll() {
    WebDriverManager.chromedriver().setup();
  }

  @BeforeEach
  void setup() {

    ChromeOptions options = new ChromeOptions();
    options.addArguments("--remote-allow-origins=*");

    driver = new ChromeDriver(options);
    driver.get("http://localhost:8080/hangman/");
  }

  @AfterEach
  void teardown() {
    driver.quit();
  }

  @Test
  void testStartNewGamePage() {

    // sets 3 seconds of timeout to load the page
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

    // checks that the title is "Welcome to Hangman"
    assertThat(driver.findElement(By.xpath("/html/body/div/h1")).getText())
        .isEqualTo("Welcome to Hangman");

    // checks that the button is "Start New Game"
    assertThat(driver.findElement(By.xpath("//*[@id=\"button\"]")).getAttribute("value"))
        .isEqualTo("Start New Game");

    // clicks to button to redirects to start game
    driver.findElement(By.cssSelector("#button")).click();

    // 3s to load the page
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

    // gets all the letters of the game and asserts that they're '*' (because of the starting
    // (position)
    List<WebElement> letters = driver.findElements(By.tagName("u"));

    for (WebElement element : letters) {
      assertThat(element.getText()).isEqualTo("*");
    }

    // asserts that the "Guess" button exists
    assertThat(
        driver.findElement(By.cssSelector("body > div.guess-form > form > input.submitButton"))
            .getAttribute("value")).isEqualTo("Guess");

    // asserts that the "Start new game" button exists
    assertThat(driver.findElement(By.cssSelector("body > form > input.submitButton"))
        .getAttribute("value")).isEqualTo("Start new game");

    // checks that the count of mistakes is 0 (because of the starting position)
    String message = driver.findElement(By.xpath("/html/body/div[3]/h4")).getText();
    assertThat(message.split(" ")[3]).isEqualTo("0");
  }

  @Test
  void testGamePageRightValues() {

    // redirects to the game and sets 3s to load
    driver.findElement(By.cssSelector("#button")).click();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

    // VALID tries to send
    char[] tries = {'a', 'e', 'o'};

    for (int i = 0; i < tries.length; i++) {

      // sends each try as guess
      driver.findElement(By.cssSelector("#input")).sendKeys(Character.toString(tries[i]));
      driver.findElement(By.cssSelector("body > div.guess-form > form > input.submitButton"))
          .click();

      // gets the picked elements and keep their color
      // num is util to follow's the path's guess numbers as the for iterates
      String num = (i == 0) ? "" : ":nth-child(" + (i + 1) + ")";
      String color = driver.findElement(By.cssSelector("body > div.guess-history > div > p" + num))
          .getCssValue("color");

      // asserts that the color is RED or GREEN
      assertThat(color).isIn("rgba(255, 0, 0, 1)", "rgba(0, 128, 0, 1)");

      // checks that if RED the count of wrong guesses is changed
      if (color.equals("red")) {
        String message = driver.findElement(By.xpath("/html/body/div[3]/h4")).getText();
        assertThat(message.split(" ")[3]).isNotEqualTo("0");
      }

      // checks that the word letters are only the ones we used to iterate
      List<WebElement> letters = driver.findElements(By.tagName("u"));

      for (WebElement element : letters) {
        assertThat(element.getText()).isIn("*", "a", "e", "o");
      }
    }
  }

  @Test
  void testGamePageWrongValues() {

    // redirects to the game and sets 3s to load
    driver.findElement(By.cssSelector("#button")).click();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

    // INVALID tries to send
    char[] tries = {'@', '!', '#'};

    for (int i = 0; i < tries.length; i++) {

      // sends each try as request
      driver.findElement(By.cssSelector("#input")).sendKeys(Character.toString(tries[i]));
      driver.findElement(By.cssSelector("body > div.guess-form > form > input.submitButton"))
          .click();

      // checks that the error message is shown
      assertThat(
          driver.findElement(By.cssSelector("body > div.guess-form > form > span")).getText())
              .isEqualTo("Field should contain single, lowercase letter.");

      // checks that the wrong guesses aren't changed, because those inputs are INVALID not wrong
      String message = driver.findElement(By.xpath("/html/body/div[3]/h4")).getText();
      assertThat(message.split(" ")[3]).isEqualTo("0");

      // checks that the word's letters aren't revealed
      List<WebElement> letters = driver.findElements(By.tagName("u"));

      for (WebElement element : letters) {
        assertThat(element.getText()).isEqualTo("*");
      }
    }
  }

  @Test
  void testLose() {

    // redirects to the game and sets 3s to load
    driver.findElement(By.cssSelector("#button")).click();
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));

    // declares all the valid inputs
    char[] tries = "qwertyuiopasdfghjklzxcvbnm".toCharArray();
    int counter = 0;

    // checks that the count of wrong guesses is 0
    String message = driver.findElement(By.xpath("/html/body/div[3]/h4")).getText();
    assertThat(message.split(" ")[3]).isEqualTo("0");

    // while the count is under 5 send wrong guesses
    while (Integer.parseInt(message.split(" ")[3]) < 5) {

      message = driver.findElement(By.xpath("/html/body/div[3]/h4")).getText();

      driver.findElement(By.cssSelector("#input")).sendKeys(Character.toString(tries[counter]));
      driver.findElement(By.cssSelector("body > div.guess-form > form > input.submitButton"))
          .click();
      counter++;
    }

    // check that we're redirected to LOSE or WIN page
    assertThat(driver.findElement(By.cssSelector("body > h1")).getText()).isIn("You LOSE!",
        "You WIN!");

    // checks that the go back button is working
    driver.findElement(By.cssSelector("body > a")).click();

    // checks that the button redirected us to the right page
    assertThat(driver.findElement(By.cssSelector("#heading")).getText())
        .isEqualTo("Welcome to Hangman");
  }
}

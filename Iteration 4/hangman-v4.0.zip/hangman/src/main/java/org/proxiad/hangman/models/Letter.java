package org.proxiad.hangman.models;

public class Letter {

  private char letter;
  private boolean isCorrect;

  public Letter(char letter, boolean isCorrect) {
    super();
    this.letter = letter;
    this.isCorrect = isCorrect;
  }

  public char getLetter() {
    return letter;
  }

  public void setLetter(char letter) {
    this.letter = letter;
  }

  public boolean isCorrect() {
    return isCorrect;
  }

  public void setCorrect(boolean isCorrect) {
    this.isCorrect = isCorrect;
  }


}

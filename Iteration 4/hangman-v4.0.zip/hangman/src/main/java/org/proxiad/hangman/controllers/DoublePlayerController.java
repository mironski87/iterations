package org.proxiad.hangman.controllers;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.validate.WordInputValidator;
import org.proxiad.hangman.service.HangmanService;
import org.proxiad.hangman.utility.PrintWordUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DoublePlayerController {

  private HangmanService service;

  public DoublePlayerController(HangmanService service) {
    this.service = service;
  }

  @PostMapping("/pickWord")
  public String getPickWord(
      @Valid @ModelAttribute("wordInputValidator") WordInputValidator wordValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    if (bindingResult.hasErrors()) {
      model.addAttribute("errors", bindingResult);
      return "pick-word";
    }

    boolean isCyrillic = isCyrillic(wordValidator);
    boolean isLatin = isLatin(wordValidator);

    if (isCyrillic || isLatin) {

      session.setAttribute("isEnglish", isLatin(wordValidator));
      Game game = service.startNewGame(session.getId(), wordValidator.getWord());
      PrintWordUtil.print(game);

      model.addAttribute("game", game);
      return "game";
    }

    model.addAttribute("message", "Just error");
    return "error";
  }

  private boolean isCyrillic(WordInputValidator wordValidator) {

    for (Character letter : wordValidator.getWord().toCharArray()) {
      if (letter < 'а' || letter > 'я') {
        return false;
      }
    }
    return true;
  }

  private boolean isLatin(WordInputValidator wordValidator) {

    for (Character letter : wordValidator.getWord().toCharArray()) {
      if (letter < 'a' || letter > 'z') {
        return false;
      }
    }
    return true;
  }
}

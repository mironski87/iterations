package org.proxiad.hangman.controllers;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.Optional;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Letter;
import org.proxiad.hangman.models.validate.InputValidator;
import org.proxiad.hangman.models.validate.LanguageValidator;
import org.proxiad.hangman.service.HangmanService;
import org.proxiad.hangman.utility.PrintWordUtil;
import org.proxiad.hangman.validate.MyCustomValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SinglePlayerController {

  private HangmanService service;
  private Optional<MyCustomValidator> validator;

  public SinglePlayerController(HangmanService service,
      @Autowired(required = false) Optional<MyCustomValidator> validator) {
    this.service = service;
    this.validator = validator;
  }

  @PostMapping("/startNewGame")
  public String startNewGame(
      @Valid @ModelAttribute("languageValid") LanguageValidator languageValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    session.setAttribute("isEnglish", "english".equals(languageValidator.getLanguage()));

    if (bindingResult.hasErrors()) {
      model.addAttribute("language", new LanguageValidator());
      model.addAttribute("errors", bindingResult);
      return "index";
    }

    Game game =
        service.startNewGame(session.getId(), "english".equals(languageValidator.getLanguage()));
    PrintWordUtil.print(game);

    setModel(model, game);
    return "game";
  }

  @PostMapping("/makeTry")
  public String makeTry(@ModelAttribute("inputValidator") InputValidator inputValidator,
      BindingResult bindingResult, HttpSession session, Model model) {

    Game game = service.getGame(session.getId());
    System.out.println(validator.isPresent());

    if (validator != null && validator.isPresent()
        && !validator.get().isValid(inputValidator.getInput())) {

      System.out.println("Validated!");
      model.addAttribute("language", new LanguageValidator());
      model.addAttribute("errors", bindingResult);
      return "index";
    }

    if (bindingResult.hasErrors()) {
      setModel(model, game);
      model.addAttribute("errors", bindingResult);
      return "game";
    }

    Letter letter = new Letter(inputValidator.getInput().charAt(0), false);
    boolean isEnglish = (boolean) session.getAttribute("isEnglish");

    // if (LatinCyrillicInputValidator.validate(isEnglish, letter)) {

    game = service.makeGuess(game.getGameId(), letter);

    if (game.isWon() || game.isLost()) {
      service.deleteGame(game.getGameId());
      model.addAttribute("isWon", game.isWon());
      return "result";
      // }
    }

    setModel(model, game);
    return "game";
  }

  private void setModel(Model model, Game game) {

    model.addAttribute("game", game);
    model.addAttribute("inputValidator", new InputValidator());
    model.addAttribute("language", new LanguageValidator());
  }
}

package org.proxiad.hangman.validate;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.ArrayList;
import java.util.List;
import org.proxiad.hangman.models.Letter;
import org.proxiad.hangman.models.RandomProperty;
import org.proxiad.hangman.utility.LatinCyrillicInputValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class TryInputConstraintValidator implements ConstraintValidator<ValidTryInput, String> {

  @Autowired
  private ApplicationContext context;

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {

    List<String> errors = new ArrayList<>();

    RandomProperty property = getProperty();
    System.out.println("Property in validator is " + property.getMyProperty());

    if (property.getMyProperty() == 1) {
      return true;
    }

    if (value == null) {
      errors.add("This field is required.");
    }

    if (value.length() != 1) {
      errors.add("This field should be 1 symbol.");
    }

    if (!LatinCyrillicInputValidator.validate(true, new Letter(value.charAt(0), false))
        && !LatinCyrillicInputValidator.validate(false, new Letter(value.charAt(0), false))) {
      errors.add("This field should be latin or cyrillic letter.");
    }

    if (errors.size() != 0) {

      context.disableDefaultConstraintViolation();
      context.buildConstraintViolationWithTemplate(String.join(" ", errors))
          .addConstraintViolation();

      return false;
    }

    return true;
  }

  private RandomProperty getProperty() {
    return context.getBean(RandomProperty.class);
  }

}

package org.proxiad.hangman.validate;

public class MyCustomValidator {

  public boolean isValid(String value) {

    if (value.length() != 1) {
      return false;
    }

    return value.matches("^[\\\\u0430-\\\\u044f]$|^[\\\\p{IsLatin}]$");
  }
}

package org.proxiad.hangman.utility;

import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Letter;

public class PrintWordUtil {

  private PrintWordUtil() {

  }

  public static void print(Game game) {

    for (Letter letter : game.getWord()) {
      System.out.print(letter.getLetter());
    }

    System.out.println();
  }
}

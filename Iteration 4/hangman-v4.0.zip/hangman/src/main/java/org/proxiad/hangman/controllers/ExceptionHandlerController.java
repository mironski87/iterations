package org.proxiad.hangman.controllers;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ExceptionHandlerController {

  @ExceptionHandler(Exception.class)
  @ResponseBody
  public String handleException(Exception ex) {

    String title = "<h1>Error</h1>";
    String message = "<p>An EXCEPTION occured: " + ex.getMessage() + "</p>";
    String goBackHref = "<a href='./'>Go back</a>";

    return title + message + goBackHref;

    // return "error";
  }
}

package org.proxiad.hangman;

import java.util.Optional;
import org.proxiad.hangman.validate.MyCustomValidator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("org.proxiad.hangman.*")
public class HangmanApplication {

  @Bean
  @ConditionalOnExpression(value = "${my.random} != 1")
  public Optional<MyCustomValidator> myCustomValidator() {
    return Optional.of(new MyCustomValidator());
  }

  public static void main(String[] args) {
    SpringApplication.run(HangmanApplication.class, args);
  }
}

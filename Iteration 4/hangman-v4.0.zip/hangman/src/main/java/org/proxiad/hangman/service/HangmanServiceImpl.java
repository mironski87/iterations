package org.proxiad.hangman.service;

import java.util.ArrayList;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Letter;
import org.proxiad.hangman.repository.GameRepository;
import org.proxiad.hangman.utility.RandomWordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HangmanServiceImpl implements HangmanService {

  private GameRepository gameRepository;

  @Autowired
  public HangmanServiceImpl(GameRepository gameRepository) {
    this.gameRepository = gameRepository;
  }

  @Override
  public Game startNewGame(String sessionId, boolean isEnglish) {

    if (gameRepository.getGameById(sessionId) != null) {
      deleteGame(sessionId);
    }

    Game game = new Game(sessionId, RandomWordUtil.generate(isEnglish));
    gameRepository.addGame(game);

    return game;
  }

  @Override
  public Game startNewGame(String sessionId, String word) {

    if (gameRepository.getGameById(sessionId) != null) {
      deleteGame(sessionId);
    }

    List<Letter> letterWord = new ArrayList<>();

    for (Character letter : word.toCharArray()) {
      letterWord.add(new Letter(letter, false));
    }

    Game game = new Game(sessionId, letterWord);
    gameRepository.addGame(game);

    return game;
  }

  @Override
  public Game getGame(String gameId) {
    return gameRepository.getGameById(gameId);
  }

  @Override
  public Game makeGuess(String gameId, Letter letter) {

    Game game = gameRepository.getGameById(gameId);

    if (doGameTriesContainsThisLetter(game, letter)) {
      return game;
    }

    boolean doWordContainsTheLetter = doWordContains(game, letter);

    letter.setCorrect(doWordContainsTheLetter);
    game.getAlphabetsPicked().add(letter);

    if (!doWordContainsTheLetter) {
      game.addWrongAttemptCount();
    }

    gameRepository.updateGame(game);
    return game;
  }

  @Override
  public void deleteGame(String gameId) {

    Game game = gameRepository.getGameById(gameId);
    gameRepository.deleteGame(game);
  }

  // checks if this word was already given as pick
  public boolean doGameTriesContainsThisLetter(Game game, Letter letter) {

    for (Letter letterItem : game.getAlphabetsPicked()) {
      if (letterItem.getLetter() == letter.getLetter()) {
        return true;
      }
    }

    return false;
  }

  // checks if the given letter is inside the game's word
  // if so: changes word's letter to true
  public boolean doWordContains(Game game, Letter letter) {

    boolean doContains = false;

    for (Letter item : game.getWord()) {
      if (item.getLetter() == letter.getLetter()) {

        item.setCorrect(true);
        doContains = true;
      }
    }

    return doContains;
  }
}

package org.proxiad.hangman.utility;

import org.proxiad.hangman.models.Letter;

public class LatinCyrillicInputValidator {

  private LatinCyrillicInputValidator() {}

  public static boolean validate(boolean isEnglish, Letter letter) {

    char charLetter = letter.getLetter();

    if (isEnglish & (charLetter < 'a' || charLetter > 'z')) {
      return false;
    }

    if (!isEnglish & (charLetter < 'а' || charLetter > 'я')) {
      return false;
    }

    return true;
  }
}

package org.proxiad.hangman.repository;

import java.util.List;
import org.proxiad.hangman.models.Game;
import org.springframework.stereotype.Component;

@Component
public class GameRepositoryImpl implements GameRepository {

  public GameRepositoryImpl() {

  }

  public List<Game> getAllGames() {
    return games;
  }

  @Override
  public Game getGameById(String gameId) {

    for (Game game : games) {
      if (game.getGameId().equals(gameId)) {
        return game;
      }
    }

    return null;
  }

  @Override
  public boolean addGame(Game game) {

    if (games.contains(game)) {
      return false;
    }

    return games.add(game);
  }

  @Override
  public boolean updateGame(Game game) {

    for (Game gameItem : games) {
      if (gameItem.getGameId().equals(game.getGameId())) {

        games.remove(gameItem);
        games.add(game);

        return true;
      }
    }

    return false;
  }

  @Override
  public boolean deleteGame(Game game) {

    for (Game gameItem : games) {
      if (gameItem.getGameId().equals(game.getGameId())) {

        games.remove(gameItem);
        return true;
      }
    }

    return false;
  }
}

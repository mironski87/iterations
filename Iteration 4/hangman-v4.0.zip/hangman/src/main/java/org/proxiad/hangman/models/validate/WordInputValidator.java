package org.proxiad.hangman.models.validate;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class WordInputValidator {

  @Size(min = 5, max = 20, message = "Atleast 5 chars and max 20 characters")
  @Pattern(regexp = "^[\\u0430-\\u044f]+$|^[a-z]+$", message = "Invalid word")
  private String word;

  public String getWord() {
    return word;
  }

  public void setWord(String word) {
    this.word = word;
  }
}

package org.proxiad.hangman.models.validate;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class LanguageValidator {

  @NotNull(message = "This field is required.")
  @Pattern(regexp = "^english$|^bulgarian$", message = "Don't change radio's values")
  private String language;

  public String getLanguage() {
    return this.language;
  }

  public void setLanguage(String language) {
    this.language = language;
  }
}

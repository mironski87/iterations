package org.proxiad.hangman.service;

import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.Letter;

public interface HangmanService {

  Game startNewGame(String sessionId, String word);

  Game startNewGame(String sessionId, boolean isEnglish);

  Game getGame(String gameId);

  Game makeGuess(String gameId, Letter letter);

  void deleteGame(String gameId);
}

package org.proxiad.hangman.controllers;

import org.proxiad.hangman.models.validate.LanguageValidator;
import org.proxiad.hangman.models.validate.WordInputValidator;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ApplicationController {

  @GetMapping("/")
  // @ResponseBody
  public String getIndex(Model model) {

    model.addAttribute("languageValidator", new LanguageValidator());
    return "index";

  }

  @GetMapping("/pickWord")
  public String getPickWordPage(Model model) {

    model.addAttribute("wordInputValidator", new WordInputValidator());
    return "pick-word";
  }
}

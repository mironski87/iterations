package org.proxiad.hangman.models;

import java.util.ArrayList;
import java.util.List;

public class Game {

  private String gameId;
  private List<Letter> word;
  private List<Letter> alphabetsPicked;
  private int wrongAttemptsCounter;

  public Game(String gameId, List<Letter> word) {

    this.gameId = gameId;
    this.word = word;
    this.wrongAttemptsCounter = 0;
    alphabetsPicked = new ArrayList<Letter>();
  }

  public String getGameId() {
    return gameId;
  }

  public void setGameId(String gameId) {
    this.gameId = gameId;
  }

  public List<Letter> getWord() {
    return word;
  }

  public void setWord(List<Letter> word) {
    this.word = word;
  }

  public List<Letter> getAlphabetsPicked() {
    return alphabetsPicked;
  }

  public void setAlphabetsPicked(List<Letter> alphabetsPicked) {
    this.alphabetsPicked = alphabetsPicked;
  }

  public int getWrongAttemptsCounter() {
    return this.wrongAttemptsCounter;
  }

  public void addWrongAttemptCount() {
    this.wrongAttemptsCounter++;
  }

  public boolean isWon() {

    for (Letter letter : this.word) {
      if (!letter.isCorrect()) {
        return false;
      }
    }

    return true;
  }

  public boolean isLost() {
    return this.wrongAttemptsCounter >= 6;
  }
}

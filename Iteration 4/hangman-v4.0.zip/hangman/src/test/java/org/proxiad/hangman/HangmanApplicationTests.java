package org.proxiad.hangman;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HangmanApplicationTests {

	@Test
	void contextLoads() {
	}

}

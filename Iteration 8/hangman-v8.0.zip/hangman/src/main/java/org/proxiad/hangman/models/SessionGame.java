package org.proxiad.hangman.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Data
@Entity
public class SessionGame {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long Id;

  private String word;

  private String history;

  @Column(name = "wrong_letters")
  private String wrongLetters;

  @Enumerated(EnumType.STRING)
  private LanguageEnum language;

  @Column(name = "is_won")
  private boolean isWon;

  @Column(name = "is_lost")
  private boolean isLost;

  public SessionGame() {
    this.word = "";
    this.history = "";
    this.wrongLetters = "";
    this.language = LanguageEnum.ENGLISH;
    this.isWon = false;
    this.isLost = false;
  }
}

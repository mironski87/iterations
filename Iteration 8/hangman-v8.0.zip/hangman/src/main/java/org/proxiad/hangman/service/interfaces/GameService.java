package org.proxiad.hangman.service.interfaces;

import java.util.List;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.validator.language.LanguageEnum;

public interface GameService {

  List<Game> listOngoingGames();

  Game startNewGame(LanguageEnum language, String sessionId);

  Game getGame(Long id);

  Game makeGuess(Long id, char letter, String sessionId);
}

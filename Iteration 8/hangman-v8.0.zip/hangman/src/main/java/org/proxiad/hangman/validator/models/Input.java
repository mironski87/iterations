package org.proxiad.hangman.validator.models;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class Input {

  private static final String ONLY_CYRILLIC_REGEX = "^[\\u0430-\\u044f]$";
  private static final String ONLY_LATIN_REGEX = "^[\\p{IsLatin}]$";

  private static final String FINAL_REGEX = ONLY_CYRILLIC_REGEX + "|" + ONLY_LATIN_REGEX;

  @NotNull(message = "This field is required.")
  @Pattern(regexp = FINAL_REGEX, message = "Field should contain single, lowercase letter.")
  private String value;
}

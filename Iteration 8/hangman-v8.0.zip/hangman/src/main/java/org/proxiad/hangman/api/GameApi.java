package org.proxiad.hangman.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import jakarta.validation.Valid;
import java.util.List;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.proxiad.hangman.dto.game.GameDTO;
import org.proxiad.hangman.dto.game.GameMappingService;
import org.proxiad.hangman.security.SecurityService;
import org.proxiad.hangman.validator.models.Input;
import org.proxiad.hangman.validator.models.Language;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class GameApi {

  private GameMappingService mappingService;
  private SecurityService securityService;

  public GameApi(GameMappingService mappingService, SecurityService securityService) {
    this.mappingService = mappingService;
    this.securityService = securityService;
  }

  @GetMapping(value = "/game", produces = APPLICATION_JSON_VALUE)
  @RequiresRoles(value = "admin")
  public ResponseEntity<List<GameDTO>> getOngoingGames() {

    if (securityService.isAdmin()) {
      return ResponseEntity.ok(mappingService.getOngoingGames());
    }

    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
  }

  @GetMapping(value = "/game/{gameId}", produces = APPLICATION_JSON_VALUE)
  public GameDTO getGame(@PathVariable String gameId) {

    if (securityService.isUser()) {
      return mappingService.getGameById(gameId);
    }

    return mappingService.getSessionGameById(gameId);
  }

  @PostMapping(value = "/game", produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  public GameDTO addNewGame(@Valid @RequestBody Language language) {

    if (securityService.isUser()) {
      return mappingService.startNewGame(language.getType(), securityService.getUserUsername());
    }

    return mappingService.startNewGame(language.getType());
  }

  @PutMapping(value = "/game/{gameId}", produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  public GameDTO makeTry(@PathVariable String gameId, @Valid @RequestBody Input input) {

    if (securityService.isUser()) {
      return mappingService.makeGuess(gameId, input.getValue().charAt(0),
          securityService.getUserUsername());
    }

    return mappingService.makeGuess(gameId, input.getValue().charAt(0));
  }
}

package org.proxiad.hangman.dto.game;

import java.util.List;
import java.util.stream.Collectors;
import org.proxiad.hangman.encoder.IdEncoder;
import org.proxiad.hangman.models.Game;
import org.proxiad.hangman.models.SessionGame;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.service.SessionGameServiceImpl;
import org.proxiad.hangman.service.interfaces.GameService;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class GameMappingServiceImpl implements GameMappingService {

  private GameService gameService;
  private SessionGameServiceImpl sessionGameService;
  private IdEncoder encoder;

  public GameMappingServiceImpl(GameService gameService, SessionGameServiceImpl sessionGameService,
      IdEncoder encoder) {
    this.gameService = gameService;
    this.sessionGameService = sessionGameService;
    this.encoder = encoder;
  }

  @Override
  public GameDTO getGameById(String encodedId) {
    return convertGameIntoDTO(gameService.getGame(encoder.decode(encodedId)));
  }

  @Override
  public GameDTO getSessionGameById(String encodedId) {
    return convertSessionGameIntoDTO(sessionGameService.getSessionGame(encoder.decode(encodedId)));
  }

  @Override
  public List<GameDTO> getOngoingGames() {

    List<Game> ongoingGames = gameService.listOngoingGames();
    return ongoingGames.stream().map(this::convertGameIntoDTO).collect(Collectors.toList());
  }

  @Override
  public GameDTO startNewGame(LanguageEnum language, String sessionId) {
    return convertGameIntoDTO(gameService.startNewGame(language, sessionId));
  }

  @Override
  public GameDTO startNewGame(LanguageEnum language) {
    return convertSessionGameIntoDTO(sessionGameService.startNewSessionGame(language));
  }

  @Override
  public GameDTO makeGuess(String encodedId, char letter, String sessionId) {
    return convertGameIntoDTO(gameService.makeGuess(encoder.decode(encodedId), letter, sessionId));
  }

  @Override
  public GameDTO makeGuess(String encodedId, char letter) {

    SessionGame sessionGame =
        sessionGameService.makeSessionGuess(encoder.decode(encodedId), letter);

    GameDTO dto = convertSessionGameIntoDTO(sessionGame);

    // if (dto.isWon() || dto.isLost()) {
    // sessionGameService.deleteOverGame(sessionGame);
    // }

    return dto;
  }

  private GameDTO convertGameIntoDTO(Game game) {

    Statistic statistic = game.getStatistic();
    GameDTO dto = new GameDTO();

    dto.setId(encoder.encode(game.getId()));
    dto.setMaskedWord(generateMaskedWord(game.getWord(), game.getHistory()));
    dto.setWrongTriesChars(statistic.getWrongLetters());
    dto.setWrongTries(statistic.getWrongTries());
    dto.setLanguage(statistic.getLanguage());
    dto.setWon(game.getStatistic().isWon());
    dto.setLost(game.getStatistic().isLost());

    return dto;
  }

  private GameDTO convertSessionGameIntoDTO(SessionGame sessionGame) {

    GameDTO dto = new GameDTO();

    dto.setId(encoder.encode(sessionGame.getId()));
    dto.setMaskedWord(generateMaskedWord(sessionGame.getWord(), sessionGame.getHistory()));
    dto.setWrongTriesChars(sessionGame.getWrongLetters());
    dto.setWrongTries(sessionGame.getWrongLetters().length());
    dto.setLanguage(sessionGame.getLanguage());
    dto.setWon(sessionGame.isWon());
    dto.setLost(sessionGame.isLost());

    return dto;
  }

  private static String generateMaskedWord(String word, String history) {

    StringBuilder builder = new StringBuilder("");

    for (Character wordChar : word.toCharArray()) {

      boolean isGuessRight = false;

      for (Character historyChar : history.toCharArray()) {

        if (wordChar.equals(historyChar)) {

          isGuessRight = true;
          break;
        }
      }

      char charToAppend = isGuessRight ? wordChar : '*';
      builder.append(charToAppend);
    }

    return builder.toString();
  }
}

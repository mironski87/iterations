package org.proxiad.hangman.repository;

import java.util.List;
import org.proxiad.hangman.models.security.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

  Role findByRole(String role);

  @Query(value = "SELECT r.role FROM User u JOIN user_role ur ON u.id = ur.user_id "
      + "JOIN Role r ON r.id = ur.role_id WHERE u.username = ?", nativeQuery = true)
  List<String> findRolesForUsername(String username);
}

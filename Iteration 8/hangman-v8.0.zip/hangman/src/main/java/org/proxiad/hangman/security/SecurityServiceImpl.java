package org.proxiad.hangman.security;

import jakarta.annotation.PostConstruct;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Component;

@Component
public class SecurityServiceImpl implements SecurityService {

  private SecurityManager securityManager;

  public SecurityServiceImpl(SecurityManager securityManager) {
    this.securityManager = securityManager;
  }

  @PostConstruct
  private void initStaticSecurityManager() {
    SecurityUtils.setSecurityManager(securityManager);
  }

  @Override
  public void login(String username, String password) {

    Subject subject = SecurityUtils.getSubject();

    if (!subject.isAuthenticated()) {

      UsernamePasswordToken token = new UsernamePasswordToken(username, password);
      subject.login(token);
      System.out.println(subject.getPrincipal() + " logged in!");
    }
  }

  @Override
  public String getUserUsername() {

    Subject subject = SecurityUtils.getSubject();

    if (subject.isAuthenticated()) {
      return subject.getPrincipal().toString();
    }

    return null;
  }

  @Override
  public boolean isUser() {

    Subject subject = SecurityUtils.getSubject();
    System.out.println(subject.getPrincipal());
    return subject.getPrincipal() != null;
  }

  @Override
  public boolean isAdmin() {

    Subject subject = SecurityUtils.getSubject();
    return subject.hasRole("admin");
  }

  @Override
  public void logout() {

    Subject subject = SecurityUtils.getSubject();

    if (subject.isAuthenticated()) {

      System.out.print(subject.getPrincipal() + " who logged out ");
      subject.logout();
      System.out.println("now is " + subject.getPrincipal());
    }
  }
}

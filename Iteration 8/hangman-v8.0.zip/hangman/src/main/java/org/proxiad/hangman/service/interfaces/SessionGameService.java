package org.proxiad.hangman.service.interfaces;

import org.proxiad.hangman.models.SessionGame;
import org.proxiad.hangman.validator.language.LanguageEnum;

public interface SessionGameService {

  SessionGame startNewSessionGame(LanguageEnum language);

  SessionGame getSessionGame(Long id);

  SessionGame makeSessionGuess(Long id, char letter);

  void deleteOverSessionGame(SessionGame sessionGame);
}

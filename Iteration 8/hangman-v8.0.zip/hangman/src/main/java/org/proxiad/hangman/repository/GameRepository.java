package org.proxiad.hangman.repository;

import jakarta.transaction.Transactional;
import java.util.List;
import org.proxiad.hangman.models.Game;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public interface GameRepository extends JpaRepository<Game, Long> {

  List<Game> findByStatisticIsWonFalseAndStatisticIsLostFalse();
}

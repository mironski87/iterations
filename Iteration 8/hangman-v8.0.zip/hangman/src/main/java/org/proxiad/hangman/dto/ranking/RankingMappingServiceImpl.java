package org.proxiad.hangman.dto.ranking;

import java.util.List;
import java.util.stream.Collectors;
import org.proxiad.hangman.models.Ranking;
import org.proxiad.hangman.service.interfaces.RankingService;
import org.springframework.stereotype.Service;

@Service
public class RankingMappingServiceImpl implements RankingMappingService {

  private RankingService rankingService;

  public RankingMappingServiceImpl(RankingService rankingService) {
    this.rankingService = rankingService;
  }

  @Override
  public List<RankingDTO> getTopTenEver() {

    return rankingService.getTopTenWinnersEver().stream().map(this::convertDataIntoDto)
        .collect(Collectors.toList());
  }

  @Override
  public List<RankingDTO> getTopTenFastestInThiryDays() {

    return rankingService.getTopTenFastestWinnersInThirtyDays().stream()
        .map(this::convertDataIntoDto).collect(Collectors.toList());
  }

  private RankingDTO convertDataIntoDto(Ranking ranking) {

    RankingDTO dto = new RankingDTO();

    dto.setFastestTime(ranking.getFastestTime());
    dto.setLastPlayed(ranking.getLastPlayed());
    dto.setNumberOfLosses(ranking.getNumberOfLosses());
    dto.setNumberOfWins(ranking.getNumberOfWins());
    dto.setSessionId(ranking.getSessionId());

    return dto;
  }
}

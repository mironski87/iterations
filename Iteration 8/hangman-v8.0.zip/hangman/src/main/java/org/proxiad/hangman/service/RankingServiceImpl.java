package org.proxiad.hangman.service;

import java.sql.Time;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import org.proxiad.hangman.models.Ranking;
import org.proxiad.hangman.models.Statistic;
import org.proxiad.hangman.repository.RankingRepository;
import org.proxiad.hangman.service.interfaces.RankingService;
import org.springframework.stereotype.Service;

@Service
public class RankingServiceImpl implements RankingService {

  private RankingRepository rankingRepo;

  public RankingServiceImpl(RankingRepository repo) {
    this.rankingRepo = repo;
  }

  @Override
  public Ranking addRanking(Statistic statistic) {

    Ranking ranking = rankingRepo.findBySessionId(statistic.getSessionId());

    if (ranking == null) {
      ranking = new Ranking();
      ranking.setSessionId(statistic.getSessionId());
    }

    setWinOrLose(statistic, ranking);
    setFastestTime(statistic, ranking);
    ranking.setLastPlayed(LocalDate.now());

    rankingRepo.save(ranking);
    return ranking;
  }

  @Override
  public Ranking findBySessionId(String sessionId) {
    return rankingRepo.findBySessionId(sessionId);
  }

  @Override
  public List<Ranking> getTopTenWinnersEver() {
    return rankingRepo.getTopTenWinners();
  }

  @Override
  public List<Ranking> getTopTenFastestWinnersInThirtyDays() {
    return rankingRepo.getTopTenFastestWinnersIn30Days();
  }

  private static void setWinOrLose(Statistic statistic, Ranking ranking) {

    if (statistic.isWon()) {
      ranking.setNumberOfWins(ranking.getNumberOfWins() + 1);

    }

    if (statistic.isLost()) {
      ranking.setNumberOfLosses(ranking.getNumberOfLosses() + 1);
    }
  }

  private static void setFastestTime(Statistic statistic, Ranking ranking) {

    Duration timeToCompleate = Duration.between(statistic.getStartTime(), statistic.getEndTime());
    Time time = Time.valueOf(LocalTime.MIDNIGHT.plus(timeToCompleate));

    if (statistic.isWon() && (ranking.getFastestTime().equals(new Time(0))
        || time.compareTo(ranking.getFastestTime()) < 0)) {
      ranking.setFastestTime(time);
    }
  }
}

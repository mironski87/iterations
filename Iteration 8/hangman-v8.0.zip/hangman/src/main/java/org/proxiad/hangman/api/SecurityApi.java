package org.proxiad.hangman.api;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.List;
import org.apache.shiro.authc.AuthenticationException;
import org.proxiad.hangman.models.security.LoginForm;
import org.proxiad.hangman.models.security.User;
import org.proxiad.hangman.security.SecurityService;
import org.proxiad.hangman.service.interfaces.RoleService;
import org.proxiad.hangman.service.interfaces.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class SecurityApi {

  private UserService userService;
  private RoleService roleService;
  private SecurityService securityService;

  public SecurityApi(UserService userService, RoleService roleService,
      SecurityService securityService) {

    this.userService = userService;
    this.roleService = roleService;
    this.securityService = securityService;
  }


  @PostMapping(path = "/login", produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> login(@RequestBody @Valid LoginForm loginForm) {

    try {
      securityService.login(loginForm.getUsername(), loginForm.getPassword());
      return ResponseEntity.ok().build();

    } catch (AuthenticationException e) {
      return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
    }
  }

  @GetMapping(path = "/current", produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<List<String>> current() {

    return ResponseEntity.ok(roleService.findRolesForUsername(securityService.getUserUsername()));
  }

  @PostMapping(path = "/register", produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> register(@Valid @RequestBody User user) {

    try {
      userService.register(user);
      return ResponseEntity.ok().build();

    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.CONFLICT).build();
    }
  }

  @PostMapping(path = "/logout")
  public ResponseEntity<Void> logout(HttpSession session) {

    securityService.logout();
    return ResponseEntity.ok().build();
  }
}

package org.proxiad.hangman.repository;

import jakarta.transaction.Transactional;
import org.proxiad.hangman.models.Statistic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public interface StatisticRepository extends JpaRepository<Statistic, Long> {

  Statistic findByGameId(Long gameId);
}

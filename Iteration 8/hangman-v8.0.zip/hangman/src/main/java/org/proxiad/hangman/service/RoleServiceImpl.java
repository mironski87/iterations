package org.proxiad.hangman.service;

import java.util.List;
import org.proxiad.hangman.models.security.Role;
import org.proxiad.hangman.repository.RoleRepository;
import org.proxiad.hangman.service.interfaces.RoleService;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

  private RoleRepository roleRepository;

  public RoleServiceImpl(RoleRepository roleRepository) {
    this.roleRepository = roleRepository;
  }

  @Override
  public Role findByName(String name) {
    return roleRepository.findByRole(name);
  }

  @Override
  public List<String> findRolesForUsername(String username) {
    return roleRepository.findRolesForUsername(username);
  }

  @Override
  public void save(Role role) {
    roleRepository.save(role);
  }
}

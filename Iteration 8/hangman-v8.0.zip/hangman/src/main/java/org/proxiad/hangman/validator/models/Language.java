package org.proxiad.hangman.validator.models;

import lombok.Data;
import org.proxiad.hangman.validator.language.CustomLanguageValidator;
import org.proxiad.hangman.validator.language.LanguageEnum;

@Data
public class Language {

  @CustomLanguageValidator
  private LanguageEnum type;
}

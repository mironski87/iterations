package org.proxiad.hangman.security;

public interface SecurityService {

  void login(String username, String password);

  String getUserUsername();

  boolean isUser();

  boolean isAdmin();

  void logout();
}

package org.proxiad.hangman.service.interfaces;

import java.util.List;
import org.proxiad.hangman.models.security.Role;

public interface RoleService {

  Role findByName(String name);

  List<String> findRolesForUsername(String username);

  void save(Role role);
}

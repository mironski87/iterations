package org.proxiad.hangman.repository;

import jakarta.transaction.Transactional;
import org.proxiad.hangman.models.security.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
@Transactional
public interface UserRepository extends JpaRepository<User, Long> {

  User findByUsername(String username);
}

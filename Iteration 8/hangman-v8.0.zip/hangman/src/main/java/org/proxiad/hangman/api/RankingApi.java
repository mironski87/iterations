package org.proxiad.hangman.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import java.util.List;
import org.proxiad.hangman.dto.ranking.RankingDTO;
import org.proxiad.hangman.dto.ranking.RankingMappingService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class RankingApi {

  private RankingMappingService rankingMappingService;

  public RankingApi(RankingMappingService rankingMappingService) {
    this.rankingMappingService = rankingMappingService;
  }

  @GetMapping(value = "/ranking/topTenEver", produces = APPLICATION_JSON_VALUE)
  public List<RankingDTO> getTopTenEver() {
    return rankingMappingService.getTopTenEver();
  }

  @GetMapping(value = "/ranking/topTenFastest", produces = APPLICATION_JSON_VALUE)
  public List<RankingDTO> getTopTenFastest() {
    return rankingMappingService.getTopTenFastestInThiryDays();
  }
}

package org.proxiad.hangman.service.interfaces;

import java.util.List;
import org.proxiad.hangman.models.Ranking;
import org.proxiad.hangman.models.Statistic;

public interface RankingService {

  Ranking addRanking(Statistic statistic);

  Ranking findBySessionId(String sessionId);

  List<Ranking> getTopTenWinnersEver();

  List<Ranking> getTopTenFastestWinnersInThirtyDays();
}

package org.proxiad.hangman.service.interfaces;

import java.util.Optional;
import org.proxiad.hangman.models.security.User;

public interface UserService {

  User findByUsername(String username);

  Optional<User> findById(Long id);

  void register(User user);
}

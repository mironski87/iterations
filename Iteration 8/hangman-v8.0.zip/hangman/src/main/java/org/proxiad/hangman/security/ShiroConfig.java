package org.proxiad.hangman.security;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.realm.jdbc.JdbcRealm;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.mgt.WebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ShiroConfig {

  @Bean
  public Realm realm(DataSource dataSource) {

    JdbcRealm realm = new JdbcRealm();
    realm.setDataSource(dataSource);
    realm.setAuthenticationQuery("select password from user where username = ?");
    realm.setUserRolesQuery("SELECT r.role FROM User u JOIN user_role ur ON u.id = ur.user_id "
        + "JOIN Role r ON r.id = ur.role_id WHERE u.username = ?");
    realm.setCachingEnabled(true);
    return realm;
  }

  @Bean
  public ShiroFilterFactoryBean shiroFilterFactoryBean(SecurityManager securityManager) {

    ShiroFilterFactoryBean factoryBean = new ShiroFilterFactoryBean();
    factoryBean.setSecurityManager(securityManager);
    factoryBean.setLoginUrl("/");

    Map<String, String> filterChainDefinitionMap = new LinkedHashMap<>();
    filterChainDefinitionMap.put("/ranking/**", "authc");
    filterChainDefinitionMap.put("/", "anon");

    factoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
    return factoryBean;
  }

  @Bean(name = "securityManager")
  public WebSecurityManager securityManager(Realm realm) {

    DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();
    securityManager.setRealm(realm);
    return securityManager;
  }
}

package org.proxiad.hangman.service;

import org.proxiad.hangman.models.SessionGame;
import org.proxiad.hangman.repository.SessionGameRepository;
import org.proxiad.hangman.service.interfaces.SessionGameService;
import org.proxiad.hangman.utility.RandomWordUtil;
import org.proxiad.hangman.validator.language.LanguageEnum;
import org.springframework.stereotype.Service;

@Service
public class SessionGameServiceImpl implements SessionGameService {

  private SessionGameRepository sessionGameRepository;

  public SessionGameServiceImpl(SessionGameRepository sessionGameRepository) {
    this.sessionGameRepository = sessionGameRepository;
  }

  @Override
  public SessionGame startNewSessionGame(LanguageEnum language) {

    SessionGame game = new SessionGame();
    game.setWord(RandomWordUtil.generate(language));
    System.out.println(game.getWord());

    game = sessionGameRepository.save(game);
    return game;
  }

  @Override
  public SessionGame getSessionGame(Long id) {
    return sessionGameRepository.findById(id).orElse(null);
  }

  @Override
  public SessionGame makeSessionGuess(Long id, char letter) {

    SessionGame game = getSessionGame(id);

    if (isLetterAlreadySubmitted(game, letter)) {
      return game;
    }

    if (isLetterWrong(game, letter)) {
      game.setWrongLetters(game.getWrongLetters() + letter);
    }

    game.setHistory(game.getHistory() + letter);

    if (isGameWon(game) || isGameLost(game)) {

      game.setWon(isGameWon(game));
      game.setLost(isGameLost(game));
    }

    sessionGameRepository.save(game);

    return game;
  }

  @Override
  public void deleteOverSessionGame(SessionGame sessionGame) {
    sessionGameRepository.delete(sessionGame);
  }

  private static boolean isLetterAlreadySubmitted(SessionGame game, char letter) {
    return game.getHistory().contains(letter + "");
  }

  private static boolean isLetterWrong(SessionGame game, char letter) {
    return !game.getWord().contains(letter + "");
  }

  private static boolean isGameWon(SessionGame sessionGame) {

    for (Character wordChar : sessionGame.getWord().toCharArray()) {

      boolean isWordCharInHistory = false;

      for (Character historyChar : sessionGame.getHistory().toCharArray()) {

        if (wordChar.equals(historyChar)) {
          isWordCharInHistory = true;
          break;
        }
      }

      if (!isWordCharInHistory) {
        return false;
      }
    }

    return true;
  }

  private static boolean isGameLost(SessionGame sessionGame) {
    return sessionGame.getWrongLetters().length() >= 6;
  }
}

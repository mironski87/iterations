package org.proxiad.hangman.dto.ranking;

import java.util.List;

public interface RankingMappingService {

  List<RankingDTO> getTopTenEver();

  List<RankingDTO> getTopTenFastestInThiryDays();
}

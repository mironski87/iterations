package org.proxiad.hangman.models.security;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.Pattern;
import java.util.HashSet;
import java.util.Set;
import lombok.Data;

@Data
@Entity
public class User {

  private static final String ONLY_LETTERS_NUMBERS_DASHES_REGEX = "^[a-zA-Z1-9_-]+$";
  private static final String LETTERS_NUMBERS_DASHES_REGEX = "[a-zA-Z1-9_-]+";
  private static final String LND_GEMAIL_REGEX = "^" + LETTERS_NUMBERS_DASHES_REGEX + "@gmail.com$";

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Pattern(regexp = ONLY_LETTERS_NUMBERS_DASHES_REGEX, message = "Unallowed symbols are used.")
  @Column(unique = true, length = 30)
  private String username;

  @Pattern(regexp = ONLY_LETTERS_NUMBERS_DASHES_REGEX, message = "Unallowed symbols are used.")
  @Column(length = 30)
  private String password;

  @Pattern(regexp = LND_GEMAIL_REGEX, message = "Invalid gmail.")
  @Column(length = 30)
  private String email;


  @ManyToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
  @JoinTable(name = "user_role", joinColumns = {@JoinColumn(name = "user_id")},
      inverseJoinColumns = {@JoinColumn(name = "role_id")})
  Set<Role> roles = new HashSet<>();
}

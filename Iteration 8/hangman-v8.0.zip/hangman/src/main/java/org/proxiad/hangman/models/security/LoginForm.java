package org.proxiad.hangman.models.security;

import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class LoginForm {

  private static final String ONLY_LETTERS_NUMBERS_DASHES_REGEX = "^[a-zA-Z1-9_-]+$";

  @Pattern(regexp = ONLY_LETTERS_NUMBERS_DASHES_REGEX, message = "Unallowed symbols are used.")
  private String username;

  @Pattern(regexp = ONLY_LETTERS_NUMBERS_DASHES_REGEX, message = "Unallowed symbols are used.")
  private String password;
}

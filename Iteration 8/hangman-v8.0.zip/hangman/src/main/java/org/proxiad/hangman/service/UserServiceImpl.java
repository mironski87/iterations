package org.proxiad.hangman.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import org.proxiad.hangman.models.security.Role;
import org.proxiad.hangman.models.security.User;
import org.proxiad.hangman.repository.UserRepository;
import org.proxiad.hangman.service.interfaces.RoleService;
import org.proxiad.hangman.service.interfaces.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

  private UserRepository userRepository;
  private RoleService roleService;

  public UserServiceImpl(UserRepository userRepository, RoleService roleService) {
    this.userRepository = userRepository;
    this.roleService = roleService;
  }

  @Override
  public User findByUsername(String username) {
    return userRepository.findByUsername(username);
  }

  @Override
  public Optional<User> findById(Long id) {
    return userRepository.findById(id);
  }

  @Override
  public void register(User user) {

    Set<Role> role = new HashSet<>();
    role.add(roleService.findByName("user"));

    user.setRoles(role);
    userRepository.save(user);
  }
}

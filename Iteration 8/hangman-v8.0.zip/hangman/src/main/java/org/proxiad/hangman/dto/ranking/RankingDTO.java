package org.proxiad.hangman.dto.ranking;

import java.sql.Time;
import java.time.LocalDate;
import lombok.Data;

@Data
public class RankingDTO {

  private String sessionId;
  private Integer numberOfWins;
  private Integer numberOfLosses;
  private Time fastestTime;
  private LocalDate lastPlayed;
}

import { useState } from "react";
import { Container } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import useSWR from "swr";

import EnglishForm from "./language_components/result_form/EnglishForm.js";
import BulgarianForm from "./language_components/result_form/BulgarianForm.js";

import RenderTopRanking from "./RenderTopRanking.js";


function ResultEnglishPage() {

    const navigate = useNavigate();
    let { gameId } = useParams();

    const [isEnglish, setIsEnglish] = useState(true);

    const { data: game, error } = useSWR(`http://localhost:8080/game/${gameId}`, async (url) => {
        const response = await fetch(url);
        return await response.json();
    });

    function onChange(e) {
        setIsEnglish(e.target.value === 'ENGLISH');
    }

    const startNewGame = async (e) => {

        e.preventDefault();

        const response = await fetch(`http://localhost:8080/game`, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ type: isEnglish ? 'ENGLISH' : 'BULGARIAN' })
        });

        const newGame = await response.json();

        if (newGame) {
            navigate(`/game/${newGame.id}`);
        }
    }

    if (error) return <div>Error loading data</div>;
    if (!game) return <div>Loading...</div>;

    return (
        <Container>

            {isEnglish
                ? <EnglishForm onSubmit={startNewGame} onChange={onChange} isWon={game.won} />
                : <BulgarianForm onSubmit={startNewGame} onChange={onChange} isWon={game.won} />}

            <RenderTopRanking />
        </Container>
    );
}

export default ResultEnglishPage;
import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

import App from './App';
import GameEnglishPage from './GamePage';
import ResultEnglishPage from './ResultPage';

import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import LoginForm from './security/LoginForm';
import RegisterForm from './security/RegisterForm';
import OngoingGames from './security/OngoingGames';

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />
  },
  {
    path: "/game/:gameId",
    element: <GameEnglishPage />
  },
  {
    path: "/result/:gameId",
    element: <ResultEnglishPage />
  },
  {
    path: "/login",
    element: <LoginForm />
  },
  {
    path: "/register",
    element: <RegisterForm />
  },
  {
    path: "/game",
    element: <OngoingGames />
  }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

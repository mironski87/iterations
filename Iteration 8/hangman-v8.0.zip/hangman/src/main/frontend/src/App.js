import { useState } from 'react';
import { Button, Container } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

import EnglishForm from "./language_components/app_form/EnglishForm";
import BulgarianForm from "./language_components/app_form/BulgarianForm";
import useRoles from './security/useRoles';

function App() {

  const navigate = useNavigate();
  const [isEnglish, setIsEnglish] = useState(true);
  const roles = useRoles();

  function onChange(e) {
    setIsEnglish(e.target.value === 'ENGLISH');
  }

  function login() {
    navigate('/login');
  }

  function register() {
    navigate('/register');
  }

  function logout() {

    fetch(`/logout`, {
      method: 'POST'
    });

    window.location.reload(false);
  }

  function ongoingGames() {
    navigate('/game');
  }

  async function startNewGame(e) {

    e.preventDefault();

    const response = await fetch(`/game`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ type: isEnglish ? 'ENGLISH' : 'BULGARIAN' })
    });

    const game = await response.json();

    if (response.status === 200 && game) {
      navigate(`/game/${game.id}`);
    }
  };

  return (
    <Container>
      {isEnglish
        ? <EnglishForm onSubmit={startNewGame} onChange={onChange} />
        : <BulgarianForm onSubmit={startNewGame} onChange={onChange} />}

      {(!roles || roles.length === 0) && <Button onClick={login}>Login</Button>}

      {(!roles || roles.length === 0) && <Button onClick={register}>Register</Button>}

      {(roles && roles.length !== 0) && <Button onClick={logout}>Logout</Button>}

      {roles && roles.includes('admin') && <Button onClick={ongoingGames}>OngoingGames</Button>}
    </Container >
  );
}

export default App;
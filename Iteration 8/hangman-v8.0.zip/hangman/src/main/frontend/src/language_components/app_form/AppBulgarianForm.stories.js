import React from "react";
import BulgarianForm from "./BulgarianForm";

export default {
    title: "AppBulgarianForm",
    component: BulgarianForm
};

const Template = (args) => <BulgarianForm {...args} />

export const Default = Template.bind({});
Default.args = {};
import React from "react";
import BulgarianForm from "./BulgarianForm";

const game = {
    id: "test",
    maskedWord: "*****",
    wrongTriesChars: "абв",
    wrongTries: 3,
    language: "BULGARIAN"
}

export default {
    title: "GameBulgarianForm",
    component: BulgarianForm
};

const Template = (args) => <BulgarianForm {...args} />

export const Default = Template.bind({game});
Default.args = {game};
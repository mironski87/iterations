import { Form } from "react-bootstrap";

import EnglishResultMessage from "./result_message/EnglishResultMessage";

import EnglishRadioMain from "../radio/EnglishRadioMain";
import BulgarianRadioSecondary from "../radio/BulgarianRadioSecondary";

import EnglishButton from "../button/EnglishButton";

    function EnglishForm({ onSubmit, onChange, isWon}) {

    return (
        <div>
            <EnglishResultMessage isWon={isWon} />

            <Form onSubmit={onSubmit}>
                <EnglishRadioMain onChange={onChange} />
                <BulgarianRadioSecondary onChange={onChange} />
                <EnglishButton />
            </Form>
        </div>
    );
}

export default EnglishForm;
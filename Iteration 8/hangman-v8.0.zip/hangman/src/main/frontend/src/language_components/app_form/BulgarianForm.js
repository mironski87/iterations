import { Form } from "react-bootstrap";

import BulgarianWelcomeHeading from "./welcome/BulgarianWelcomeHeading";

import EnglishRadioSecondary from "../radio/EnglishRadioSecondary";
import BulgarianRadioMain from "../radio/BulgarianRadioMain";

import BulgarianButton from "../button/BulgarianButton";

    function EnglishForm({ onSubmit, onChange}) {

    return (
        <div>
            <BulgarianWelcomeHeading />

            <Form onSubmit={onSubmit}>
                <EnglishRadioSecondary onChange={onChange} />
                <BulgarianRadioMain onChange={onChange} />
                <BulgarianButton />
            </Form>
        </div>
    );
}

export default EnglishForm;
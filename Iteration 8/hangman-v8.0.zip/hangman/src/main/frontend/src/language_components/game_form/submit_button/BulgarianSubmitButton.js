import { Button } from "react-bootstrap";

function BulgarianSubmitButton() {

    return (
        <Button variant='primary' type='submit'>
            Изпрати
        </Button>
    );
}

export default BulgarianSubmitButton;
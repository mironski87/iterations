import { Button } from "react-bootstrap";

function BulgarianButton() {

    return (
        <Button variant='primary' type='submit'>
            Нова игра
        </Button>
    );
}

export default BulgarianButton;
import React from "react";
import EnglishWelcomeHeading from "./EnglishWelcomeHeading";

export default {
    title: "EnglishWelcomeHeading",
    component: EnglishWelcomeHeading
};

const Template = (args) => <EnglishWelcomeHeading {...args} />

export const Default = Template.bind({});
Default.args = {};
import { Form } from "react-bootstrap";

function BulgarianRadioMain({ onChange }) {

  return (
    <Form.Check
      type='radio'
      name='type'
      label='Български'
      value='BULGARIAN'
      onChange={onChange}
      defaultChecked
    />
  );
}

export default BulgarianRadioMain;
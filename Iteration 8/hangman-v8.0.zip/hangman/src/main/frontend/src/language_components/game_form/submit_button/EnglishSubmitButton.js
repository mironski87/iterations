import { Button } from "react-bootstrap";

function EnglishSubmitButton() {

    return (
        <Button variant='primary' type='submit'>
            Submit
        </Button>
    );
}

export default EnglishSubmitButton;
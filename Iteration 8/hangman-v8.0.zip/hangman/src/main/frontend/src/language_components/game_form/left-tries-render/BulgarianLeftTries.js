
function BulgarianLeftTries({ game }) {

    return (
        <div>
            <h1>{game.maskedWord}</h1>

            <h2>{game.wrongTriesChars}</h2>

            <h2>Остават ти {6 - game.wrongTries} опита.</h2>
        </div>
    );
}

export default BulgarianLeftTries;
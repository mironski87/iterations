function EnglishResultMessage({ isWon }) {

    const result = isWon ? 'СПЕЧЕЛИ' : 'ЗАГУБИ';

    return (
        <h1>Ти {result} играта!</h1>
    );
}

export default EnglishResultMessage;
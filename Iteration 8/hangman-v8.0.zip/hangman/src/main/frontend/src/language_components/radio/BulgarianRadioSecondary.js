import { Form } from "react-bootstrap";

    function BulgarianRadioSecondary({onChange}, ) {

    return (
        <Form.Check
          type='radio'
          name='type'
          label='Български'
          value='BULGARIAN'
          onChange={onChange}
        />
    );
}

export default BulgarianRadioSecondary;
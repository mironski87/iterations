function EnglishResultMessage({ isWon }) {

    const result = isWon ? 'WON' : 'LOST';

    return (
        <h1>You {result} the game!</h1>
    );
}

export default EnglishResultMessage;
import { Form } from "react-bootstrap";

import EnglishWelcomeHeading from "./welcome/EnglishWelcomeHeading";

import EnglishRadioMain from "../radio/EnglishRadioMain";
import BulgarianRadioSecondary from "../radio/BulgarianRadioSecondary";

import EnglishButton from "../button/EnglishButton";

    function EnglishForm({ onSubmit, onChange}) {

    return (
        <div>
            <EnglishWelcomeHeading />

            <Form onSubmit={onSubmit}>
                <EnglishRadioMain onChange={onChange} />
                <BulgarianRadioSecondary onChange={onChange} />
                <EnglishButton />
            </Form>
        </div>
    );
}

export default EnglishForm;
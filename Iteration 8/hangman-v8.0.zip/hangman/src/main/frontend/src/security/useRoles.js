import { useEffect, useState } from "react";

function useRoles() {

    const [roles, setRoles] = useState();

    useEffect(() => {

        fetch('/current')
        .then(response => response.json())
        .then(json => setRoles(json));
    }, []);

    return roles;
}

export default useRoles;
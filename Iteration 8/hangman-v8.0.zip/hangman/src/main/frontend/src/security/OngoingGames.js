import { Container, Table } from 'react-bootstrap';
import useSWR from "swr";

function OngoingGames() {

    const { data: ongoingGames, error } = useSWR(`/game`, async (url) => {
        const response = await fetch(url);
        return response.json();
    });

    if (error) return <div>Error resolving rankings...</div>

    return (
        <Container>
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>word</th>
                        <th>wrong tries</th>
                        <th>count of wrong tries</th>
                    </tr>
                </thead>
                <tbody>
                    {!ongoingGames && <div>Loading...</div>}

                    {ongoingGames && ongoingGames.map((game) => (
                        <tr key={game.id} >
                            <td>{game.maskedWord}</td>
                            <td>{game.wrongTriesChars}</td>
                            <td>{game.wrongTries}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </Container >
    );
}

export default OngoingGames;
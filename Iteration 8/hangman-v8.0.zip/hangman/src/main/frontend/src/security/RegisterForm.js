import { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from 'react-router-dom';

function RegisterForm() {

    const navigate = useNavigate();
    const [error, setError] = useState(null);

    async function submit(e) {

        e.preventDefault();

        const username = e.target.username.value;
        const password = e.target.password.value;
        const email = e.target.email.value;

        const response = await fetch(`/register`, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username: username, password: password, email: email })
        });

        if (response.status === 200) {
            navigate('/login');
        }

        if (response.status === 400) {
            setError("Invalid input.");
        }

        if (response.status === 409) {
            setError("This username is already taken.");
        }
    }

    return (
        <Form onSubmit={submit}>

            <Form.Group controlId="username">
                <Form.Label>Username:</Form.Label>
                <Form.Control type="text" />
            </Form.Group>

            <Form.Group controlId="password">
                <Form.Label>Password:</Form.Label>
                <Form.Control type="text" />
            </Form.Group>

            <Form.Group controlId="email">
                <Form.Label>Email:</Form.Label>
                <Form.Control type="email" />
            </Form.Group>

            {error && <p>{error}</p>}

            <Button variant="primary" type="submit">
                Register
            </Button>
        </Form>
    );
}

export default RegisterForm;
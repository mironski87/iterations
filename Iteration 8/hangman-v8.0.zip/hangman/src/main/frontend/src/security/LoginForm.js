import { useState } from "react";
import { Button, Form } from "react-bootstrap";
import { useNavigate } from 'react-router-dom';

function LoginForm() {

    const navigate = useNavigate();
    const [error, setError] = useState(null);

    async function submit(e) {

        e.preventDefault();

        const username = e.target.username.value;
        const password = e.target.password.value;

        const response = await fetch(`/login`, {
            method: 'POST',
            credentials: 'include',
            headers: {
                Accept: 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username: username, password: password })
        });

        if (response.status === 200) {
            navigate('/');
        }

        if (response.status === 400) {
            setError("Invalid input.");
        }

        if (response.status === 401) {
            setError("No such user!");
        }
    }

    return (
        <Form onSubmit={submit}>

            <Form.Group controlId="username">
                <Form.Label>Username:</Form.Label>
                <Form.Control type="text" />
            </Form.Group>

            <Form.Group controlId="password">
                <Form.Label>Password:</Form.Label>
                <Form.Control type="password" />
            </Form.Group>

            {error && <p>{error}</p>}

            <Button variant="primary" type="submit">
                Login
            </Button>
        </Form>
    );
}

export default LoginForm;
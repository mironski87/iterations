import { Container, Table } from 'react-bootstrap';
import useSWR from "swr";

function RenderTopRanking() {

    const { data: topTenEver, errorTopTenEver } = useSWR(`/ranking/topTenEver`, async (url) => {
        const response = await fetch(url);
        return response.json();
    });

    const { data: topTenFastest, errorTopTenFastest } = useSWR(`/ranking/topTenFastest`, async (url) => {
        const response = await fetch(url);
        return response.json();
    });

    if (errorTopTenEver || errorTopTenFastest) return <div>Error resolving rankings...</div>
    if (!topTenEver && !topTenFastest) return <></>

    return (
        <Container>
            <Table striped bordered hover>
                <caption>Top 10</caption>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Wins</th>
                        <th>Losses</th>
                        <th>Fastest time</th>
                    </tr>
                </thead>
                <tbody>
                    {!topTenEver && <div>Loading...</div>}

                    {topTenEver && topTenEver.map((ranking) => (

                        <tr key={ranking.id} >
                            <td>{ranking.sessionId}</td>
                            <td>{ranking.numberOfWins}</td>
                            <td>{ranking.numberOfLosses}</td>
                            <td>{ranking.fastestTime}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>

            <Table striped bordered hover>
                <caption>Top 10 in 30 days</caption>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Wins</th>
                        <th>Losses</th>
                        <th>Fastest time</th>
                        <th>Last played</th>
                    </tr>
                </thead>
                <tbody>
                    {!topTenFastest && <div>Loading...</div>}

                    {topTenFastest && topTenFastest.map((ranking) => (

                        <tr key={ranking.id} >
                            <td>{ranking.sessionId}</td>
                            <td>{ranking.numberOfWins}</td>
                            <td>{ranking.numberOfLosses}</td>
                            <td>{ranking.fastestTime}</td>
                            <td>{ranking.lastPlayed}</td>
                        </tr>
                    ))}
                </tbody>
            </Table >
        </Container >
    );
}

export default RenderTopRanking;
package org.proxiad.hangman.webclient;

class GameRestTest {

  // WebClient client = WebClient.create("http://localhost:8080");
  //
  // @Test
  // void testGetOngoingGames() {
  //
  // List<Game> onGoingGames =
  // client.get().uri("/games").retrieve().bodyToFlux(Game.class).collectList().block();
  //
  // assertThat(onGoingGames).isNotEmpty();
  // }
  //
  // @Test
  // void testGetGame() {
  //
  // Game game = client.get().uri("/games/{gameId}", 1L).retrieve().bodyToMono(Game.class).block();
  // assertThat(game).isNotNull();
  // assertThat(game.getId()).isEqualTo(1);
  // }
  //
  // @Test
  // void testStartNewGame() {
  //
  // Game game = client
  // .post().uri(uriBuilder -> uriBuilder.path("/addGame")
  // .queryParam("type", LanguageEnum.ENGLISH).build())
  // .retrieve().bodyToMono(Game.class).block();
  //
  // assertThat(game).isNotNull();
  // assertThat(game.getHistory()).isBlank();
  // assertThat(game.getWord()).isNotBlank();
  //
  // testMakeTry(game);
  // }
  //
  // void testMakeTry(Game game) {
  //
  // Game gameAfterTry = client.put().uri(uriBuilder -> uriBuilder.path("/makeTry/{gameId}")
  // .queryParam("value", "a").build(game.getId())).retrieve().bodyToMono(Game.class).block();
  //
  // assertThat(gameAfterTry).isNotNull();
  // assertThat(gameAfterTry.getHistory()).isEqualTo("a");
  // }
}

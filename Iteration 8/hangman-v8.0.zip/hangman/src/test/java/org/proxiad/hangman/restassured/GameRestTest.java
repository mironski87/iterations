package org.proxiad.hangman.restassured;

class GameRestTest {

  // private Base64Encoder encoder;
  //
  // @BeforeEach
  // void setup() {
  // this.encoder = new Base64Encoder();
  // }
  //
  // @Test
  // void testGetOngoingGames() {
  //
  // Response response = given().when().get("http://localhost:8080/game");
  // response.then().statusCode(HttpStatus.OK.value());
  // List<GameDTO> games = response.then().extract().body().jsonPath().getList(".", GameDTO.class);
  //
  // assertThat(games).isNotEmpty();
  //
  // for (GameDTO game : games) {
  // assertThat(game.getId()).isNotNull();
  // assertThat(game.isLost()).isFalse();
  // assertThat(game.isWon()).isFalse();
  // }
  // }
  //
  // @Test
  // void testGetGame() {
  //
  // String encodedId = encoder.encode(1L);
  //
  // GameDTO game = when().get("http://localhost:8080/game/{gameId}", encodedId).then()
  // .statusCode(HttpStatus.OK.value()).contentType(ContentType.JSON).extract()
  // .as(GameDTO.class);
  //
  // assertThat(game).isNotNull();
  //
  // Long decodedId = encoder.decode(game.getId());
  // assertThat(decodedId).isEqualTo(1L);
  // }
  //
  // @Test
  // void testStartNewGame() {
  //
  // GameDTO game = given().queryParam("type", LanguageEnum.ENGLISH)
  // .contentType(MediaType.APPLICATION_JSON_VALUE).when().post("http://localhost:8080/game")
  // .then().statusCode(HttpStatus.OK.value()).extract().as(GameDTO.class);
  //
  // assertThat(game).isNotNull();
  // assertThat(game.getWrongTriesChars()).isBlank();
  //
  // for (Character letter : game.getMaskedWord().toCharArray()) {
  // assertThat(letter).isEqualTo('*');
  // }
  //
  // testMakeTry(game);
  // }
  //
  // void testMakeTry(GameDTO game) {
  //
  // GameDTO gameAfterTry =
  // given().queryParam("value", "a").contentType(MediaType.APPLICATION_JSON_VALUE).when()
  // .put("http://localhost:8080/game/{gameId}", game.getId()).then()
  // .statusCode(HttpStatus.OK.value()).extract().as(GameDTO.class);
  //
  // assertThat(gameAfterTry).isNotNull();
  // assertThat(gameAfterTry.getWrongTriesChars()).isEqualTo("a");
  // assertThat(gameAfterTry.getWrongTries()).isEqualTo(1);
  // }
}
